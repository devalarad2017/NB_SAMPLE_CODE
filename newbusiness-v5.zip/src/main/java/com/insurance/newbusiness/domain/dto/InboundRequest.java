package com.insurance.newbusiness.domain.dto;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * InboundRequest — maps the actual JSON structure received from external partners.
 *
 * Partner sends a complex payload with multiple map objects and list objects:
 *   - pInObj1_inout, pInObj2_inout, pInObj3_inout : flat key-value maps (stringvalN → value)
 *   - pInList1_inout through pInList6_inout       : lists of dynamic key-value records
 *
 * The stringvalN params are spread across multiple pInObj maps.
 * Compatibility methods at the bottom merge them into a single Map for the
 * mapping layer (MappingService) and journey processing (JourneyContext).
 */
@Setter
@Getter
@Schema(description = "Insurance application request from external partner")
@JsonIgnoreProperties(ignoreUnknown = true)
public class InboundRequest {

    // ── Flat key-value maps — each contains stringvalN params ─────────────────
    @JsonProperty("pInObj1_inout")
    private Map<String, String> pInObj1_inout;

    @JsonProperty("pInObj2_inout")
    private Map<String, String> pInObj2_inout;

    @JsonProperty("pInObj3_inout")
    private Map<String, String> pInObj3_inout;

    // ── List objects — each contains a list of dynamic key-value records ───────
    @JsonProperty("pInList1_inout")
    private PInList pInList1_inout;

    @JsonProperty("pInList4_inout")
    private PInList pInList4_inout;

    @JsonProperty("pInList5_inout")
    private PInList pInList5_inout;

    @JsonProperty("pInList6_inout")
    private PInList pInList6_inout;

    // =========================================================================
    // Inner class: PInList — wraps a list of dynamic records
    // =========================================================================
    @Setter
    @Getter
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class PInList {
        private List<WeoRecStrings150User> WeoRecStrings150User;
    }

    // =========================================================================
    // Inner class: WeoRecStrings150User — one record with dynamic key-value pairs
    //
    // Uses @JsonAnyGetter/@JsonAnySetter so ANY JSON key-value pair in the record
    // is captured into the values map automatically. No need to define every field.
    // =========================================================================
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class WeoRecStrings150User {

        private Map<String, String> values = new HashMap<>();

        @JsonAnyGetter
        public Map<String, String> getValues() { return values; }

        @JsonAnySetter
        public void setValue(String key, String value) { this.values.put(key, value); }
    }

    // =========================================================================
    // Compatibility methods — used by NewBusinessService and JourneyContext
    // =========================================================================

    /**
     * Returns partner code from pInObj1_inout.
     * Adjust the key if partner code is under a different stringvalN.
     */
    public String getPartnerCode() {
        return pInObj1_inout != null ? pInObj1_inout.get("stringval1") : null;
    }

    /**
     * Returns ALL params merged from pInObj1, pInObj2, pInObj3 into one Map.
     *
     * This is what MappingService uses to resolve stringvalN → internal field names.
     * Merging all three ensures any stringvalN from any pInObj is available for mapping.
     * If the same key exists in multiple maps, pInObj3 wins over pInObj2 wins over pInObj1.
     */
    public Map<String, String> getParams() {
        Map<String, String> merged = new LinkedHashMap<>();
        if (pInObj1_inout != null) merged.putAll(pInObj1_inout);
        if (pInObj2_inout != null) merged.putAll(pInObj2_inout);
        if (pInObj3_inout != null) merged.putAll(pInObj3_inout);
        return merged;
    }
}
