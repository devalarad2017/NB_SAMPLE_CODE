package com.insurance.newbusiness.mapping;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

// =============================================================================
// DB-BASED MAPPING — COMMENTED OUT
// =============================================================================
// The DB-driven MappingCache loaded all rows from partner_field_mapping table
// at startup, cached them in-memory, and resolved stringvalN → internal fields
// with type conversion, transformations, and mandatory validation.
//
// Retained here so we can switch back or combine approaches later once the full
// partner_field_mapping table is populated by the BA team.
//
// To re-enable DB approach:
//   1. Uncomment MappingCache class and DB-based resolve methods below
//   2. Comment out the property-file based resolveAs/resolve methods
//   3. Uncomment MappingCache @Autowired in this class
//   4. Ensure partner_field_mapping table has data (see V1__create_tables.sql)
// =============================================================================

/*
@Component
class MappingCache {

    private static final Logger log = LoggerFactory.getLogger(MappingCache.class);

    @Autowired
    private PartnerFieldMappingRepository repository;

    // key = "partnerCode::targetApi", value = list of field mappings
    private final Map<String, List<PartnerFieldMapping>> cache = new HashMap<>();

    @PostConstruct
    public void load() {
        List<PartnerFieldMapping> all = repository.findByActiveTrue();
        cache.clear();
        for (PartnerFieldMapping m : all) {
            String key = m.getPartnerCode() + "::" + m.getTargetApi();
            cache.computeIfAbsent(key, k -> new ArrayList<>()).add(m);
        }
        log.info("MappingCache loaded — {} combinations | {} total rows", cache.size(), all.size());
    }

    public List<PartnerFieldMapping> getMappings(String partnerCode, String targetApi) {
        List<PartnerFieldMapping> mappings = cache.get(partnerCode + "::" + targetApi);
        return mappings != null ? mappings : Collections.emptyList();
    }
}
*/

// =============================================================================
// PROPERTY-FILE BASED MAPPING (active approach)
// =============================================================================
//
// How it works:
//   - Each partner + api combination has a .properties file under classpath:mapping/
//   - File name: {partnerCode}-{targetApi}.properties
//   - Fallback:  default-{targetApi}.properties
//   - Each line: stringvalN=targetFieldName
//     e.g. stringval1=firstName
//
// resolveAs() reads the properties, renames keys in the raw param map, then uses
// ObjectMapper.convertValue() to build the typed POJO — same as the DB approach.
//
// Adding a new partner: create mapping/NEW_PARTNER-ELIGIBILITY_API.properties
// Adding a new API:     create mapping/default-NEW_API.properties
// No code changes needed for either.
//
// Unmapped/blank fields are skipped with a WARN log. No exceptions for POC.
// =============================================================================
@Service
public class MappingService {

    private static final Logger log = LoggerFactory.getLogger(MappingService.class);
    private static final String MAPPING_DIR = "mapping/";

    @Autowired
    private ObjectMapper objectMapper;

    // Cache: "PARTNER_A::ELIGIBILITY_API" → {stringval1=firstName, stringval2=lastName}
    private final Map<String, Map<String, String>> cache = new ConcurrentHashMap<>();

    @PostConstruct
    public void init() {
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        log.info("MappingService initialized — property-file based mapping active");
    }

    // =========================================================================
    // resolveAs() — maps partner's raw params to a typed POJO.
    //
    // Same method signature as the old DB-based version so JourneyOrchestrator
    // code does not need to change.
    //
    // Usage:
    //   EligibilityRequest req = mappingService.resolveAs(
    //       "PARTNER_A", "ELIGIBILITY_API", rawParams, EligibilityRequest.class);
    //
    // After this, you can manually set any extra fields not in the properties:
    //   req.setEligibilityId(context.getEligibilityResult().getEligibilityId());
    // =========================================================================
    public <T> T resolveAs(String partnerCode,
                            String targetApi,
                            Map<String, String> rawParams,
                            Class<T> targetClass) {

        Map<String, Object> resolvedMap = resolve(partnerCode, targetApi, rawParams);
        return objectMapper.convertValue(resolvedMap, targetClass);
    }

    // =========================================================================
    // resolve() — returns mapped field names with values as a flat Map.
    // Use this when you want to inspect or manually tweak before POJO conversion.
    // =========================================================================
    public Map<String, Object> resolve(String partnerCode,
                                       String targetApi,
                                       Map<String, String> rawParams) {

        Map<String, String> fieldMappings = getFieldMappings(partnerCode, targetApi);

        if (fieldMappings.isEmpty()) {
            log.warn("No mappings found for partner={} api={}. " +
                     "Check mapping/*.properties files.", partnerCode, targetApi);
            return Collections.emptyMap();
        }

        Map<String, Object> resolved = new LinkedHashMap<>();

        for (Map.Entry<String, String> mapping : fieldMappings.entrySet()) {
            String sourceParam = mapping.getKey();    // e.g. stringval1
            String targetField = mapping.getValue();  // e.g. firstName

            String rawValue = rawParams.get(sourceParam);

            if (rawValue == null || rawValue.trim().isEmpty()) {
                log.debug("Blank/missing source={} for target={} — skipped", sourceParam, targetField);
                continue;
            }

            resolved.put(targetField, rawValue.trim());
        }

        log.info("Mapped {}/{} fields | partner={} api={}",
                resolved.size(), rawParams.size(), partnerCode, targetApi);

        return resolved;
    }

    // =========================================================================
    // getFieldMappings() — loads and caches properties for a partner+api pair.
    //
    // Lookup order:
    //   1. mapping/{partnerCode}-{targetApi}.properties  (partner-specific)
    //   2. mapping/default-{targetApi}.properties         (fallback for all)
    // =========================================================================
    private Map<String, String> getFieldMappings(String partnerCode, String targetApi) {
        String cacheKey = partnerCode + "::" + targetApi;

        return cache.computeIfAbsent(cacheKey, key -> {

            // Try partner-specific file first
            String partnerFile = partnerCode + "-" + targetApi + ".properties";
            Map<String, String> mappings = loadPropertiesFile(partnerFile);

            if (!mappings.isEmpty()) {
                log.info("Loaded {} mappings from {}", mappings.size(), partnerFile);
                return mappings;
            }

            // Fallback to default file
            String defaultFile = "default-" + targetApi + ".properties";
            mappings = loadPropertiesFile(defaultFile);

            if (!mappings.isEmpty()) {
                log.info("Using {} default mappings from {} for partner={}",
                        mappings.size(), defaultFile, partnerCode);
            } else {
                log.warn("No mapping file found for partner={} api={}", partnerCode, targetApi);
            }

            return mappings;
        });
    }

    private Map<String, String> loadPropertiesFile(String fileName) {
        String path = MAPPING_DIR + fileName;
        ClassPathResource resource = new ClassPathResource(path);

        if (!resource.exists()) {
            return Collections.emptyMap();
        }

        Properties props = new Properties();
        try (InputStream is = resource.getInputStream()) {
            props.load(is);
        } catch (IOException e) {
            log.error("Failed to load mapping file: {}", path, e);
            return Collections.emptyMap();
        }

        Map<String, String> map = new LinkedHashMap<>();
        for (String propKey : props.stringPropertyNames()) {
            map.put(propKey, props.getProperty(propKey));
        }
        return map;
    }

    // =========================================================================
    // Cache management — call from admin endpoint to reload without restart.
    // =========================================================================
    public void reloadAll() {
        cache.clear();
        log.info("MappingService cache cleared — properties will reload on next request");
    }

    public void reloadPartner(String partnerCode) {
        cache.entrySet().removeIf(e -> e.getKey().startsWith(partnerCode + "::"));
        log.info("Cleared cached mappings for partner={}", partnerCode);
    }
}

// =============================================================================
// DB-BASED resolve logic — commented out for reference
// =============================================================================
/*
    // The full DB-based resolve with type conversion, transformation, mandatory checks.
    // This was complex because it handled: STRING/INTEGER/DECIMAL/DATE/BOOLEAN conversion,
    // TRIM/UPPERCASE/LOWERCASE transformation, default values, mandatory validation,
    // and date format parsing — all driven by columns in partner_field_mapping table.
    //
    // For POC, the property file approach passes everything as String and lets
    // Jackson handle type coercion in convertValue(). This is simpler and works
    // for most cases. Add explicit type conversion later if needed.

    @Autowired private MappingCache mappingCache;

    public <T> T resolveAs_DB(String partnerCode, String targetApi,
                               Map<String, String> rawParams, Class<T> targetClass) {

        List<PartnerFieldMapping> mappings = mappingCache.getMappings(partnerCode, targetApi);
        Map<String, Object> resolved = new LinkedHashMap<>();
        List<String> missingFields = new ArrayList<>();

        for (PartnerFieldMapping mapping : mappings) {
            String rawValue = rawParams.get(mapping.getSourceParam());
            boolean isBlank = (rawValue == null || rawValue.trim().isEmpty());

            // Default value fallback
            if (isBlank && mapping.getDefaultValue() != null && !mapping.getDefaultValue().trim().isEmpty()) {
                rawValue = mapping.getDefaultValue();
                isBlank = false;
            }

            // Mandatory check
            if (isBlank) {
                if (mapping.isMandatory()) {
                    missingFields.add(mapping.getSourceParam() + " → " + mapping.getTargetField());
                }
                continue;
            }

            // Transform: TRIM, UPPERCASE, LOWERCASE
            String transformed = rawValue;
            if (mapping.getTransformation() != null) {
                switch (mapping.getTransformation().toUpperCase()) {
                    case "TRIM":      transformed = rawValue.trim(); break;
                    case "UPPERCASE": transformed = rawValue.trim().toUpperCase(); break;
                    case "LOWERCASE": transformed = rawValue.trim().toLowerCase(); break;
                }
            }

            // Type conversion: STRING, INTEGER, DECIMAL, BOOLEAN, DATE
            Object typed;
            switch (mapping.getDataType().toUpperCase()) {
                case "INTEGER": typed = Integer.parseInt(transformed); break;
                case "DECIMAL": typed = new java.math.BigDecimal(transformed); break;
                case "BOOLEAN": typed = Boolean.parseBoolean(transformed); break;
                case "DATE":
                    typed = java.time.LocalDate.parse(transformed,
                        java.time.format.DateTimeFormatter.ofPattern(mapping.getDateFormat()));
                    break;
                default: typed = transformed;
            }

            resolved.put(mapping.getTargetField(), typed);
        }

        if (!missingFields.isEmpty()) {
            throw new MappingValidationException(targetApi, missingFields);
        }

        return objectMapper.convertValue(resolved, targetClass);
    }
*/
