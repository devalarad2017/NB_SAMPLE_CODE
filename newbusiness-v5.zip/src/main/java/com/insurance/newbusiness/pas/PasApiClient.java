package com.insurance.newbusiness.pas;

import com.insurance.newbusiness.integration.model.pas.PasRequest;
import com.insurance.newbusiness.integration.model.pas.PasResponse;
import com.insurance.newbusiness.journey.JourneyContext;
import com.insurance.newbusiness.mapping.MappingService;
import com.insurance.newbusiness.tracking.JourneyTrackingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

/**
 * PasApiClient — submits the final application to PAS.
 *
 * PAS request is the richest in the journey — it combines:
 *   1. Partner's raw params (mapped via property file: default-PAS_API.properties)
 *   2. Response fields from ALL prior APIs (set manually — clean, explicit code)
 *   3. Context fields (correlationId, partnerCode)
 *
 * WHY MANUAL ASSIGNMENT FOR RESPONSE FIELDS:
 *   Response fields come from typed Java objects (EligibilityResponse, EdcResponse etc.)
 *   Property file mapping only works for raw string params (stringvalN).
 *   Manual assignment is compile-safe, IDE navigable, and easy to read.
 *   This is intentional — not a shortcut.
 */
@Service
public class PasApiClient {

    private static final Logger log      = LoggerFactory.getLogger(PasApiClient.class);
    private static final String STAGE    = "PAS_SUBMISSION_STAGE";
    private static final String API_NAME = "PAS_API";

    @Value("${api.endpoints.pas}")
    private String pasUrl;

    @Autowired private RestTemplate           restTemplate;
    @Autowired private MappingService         mappingService;
    @Autowired private JourneyTrackingService trackingService;

    @Retryable(value = {RuntimeException.class}, maxAttempts = 3,
               backoff = @Backoff(delay = 3000, multiplier = 2))
    public String submitAndGetApplicationNumber(JourneyContext context) {
        long start = System.currentTimeMillis();
        log.info("[{}] Submitting to PAS | url={}", context.getCorrelationId(), pasUrl);

        try {
            PasRequest pasRequest = buildPasRequest(context);

            PasResponse response = restTemplate.postForObject(
                    pasUrl, pasRequest, PasResponse.class);

            long duration = System.currentTimeMillis() - start;

            String applicationNumber = (response != null) ? response.getApplicationNumber() : null;

            if (applicationNumber == null || applicationNumber.trim().isEmpty()) {
                throw new RuntimeException("PAS returned empty applicationNumber");
            }

            trackingService.logApiCall(context, STAGE, API_NAME,
                    pasRequest, response, "SUCCESS", null, null, duration);

            log.info("[{}] PAS SUCCESS | applicationNumber={} | {}ms",
                    context.getCorrelationId(), applicationNumber, duration);

            return applicationNumber;

        } catch (RuntimeException ex) {
            long duration = System.currentTimeMillis() - start;
            trackingService.logApiCall(context, STAGE, API_NAME,
                    null, null, "FAILED", "PAS_ERROR", ex.getMessage(), duration);
            log.error("[{}] PAS FAILED | {}ms | {}",
                    context.getCorrelationId(), duration, ex.getMessage());
            throw ex;
        }
    }

    /**
     * Builds PasRequest in two steps:
     *
     * Step 1: Map partner's raw stringvalN params via property file
     *         (mapping/default-PAS_API.properties or partner-specific file)
     *         This fills: firstName, lastName, dob, panNumber, sumAssured, etc.
     *
     * Step 2: Set response fields from prior APIs manually.
     *         These are typed, compile-safe assignments.
     *         Each section is clearly labelled with the source API.
     */
    private PasRequest buildPasRequest(JourneyContext context) {

        // Step 1: Map raw partner params → PasRequest fields via property file
        PasRequest req = mappingService.resolveAs(
                context.getPartnerCode(), "PAS_API",
                context.getRawParams(), PasRequest.class);

        // Step 2: Set context fields
        req.setCorrelationId(context.getCorrelationId());
        req.setPartnerCode(context.getPartnerCode());

        // Step 3: Set fields from Eligibility API response
        if (context.getEligibilityResult() != null) {
            req.setEligibilityId(context.getEligibilityResult().getEligibilityId());
            req.setEligibilityStatus(context.getEligibilityResult().getStatus());
            req.setAgeAtEntry(context.getEligibilityResult().getAgeAtEntry());
        }

        // Step 4: Set fields from Scoring API responses (EDC, PASA, TASA)
        if (context.getEdcResult() != null) {
            req.setCreditScore(context.getEdcResult().getCreditScore());
            req.setCreditBureau(context.getEdcResult().getCreditBureau());
        }
        if (context.getPasaResult() != null) {
            req.setPasaScore(context.getPasaResult().getPasaScore());
            req.setPasaScoreGrade(context.getPasaResult().getScoreGrade());
        }
        if (context.getTasaResult() != null) {
            req.setTasaScore(context.getTasaResult().getTasaScore());
            req.setTasaRiskCategory(context.getTasaResult().getRiskCategory());
        }

        // Step 5: Set fields from Medical API response
        if (context.getMedicalResult() != null) {
            req.setMedicalRefId(context.getMedicalResult().getMedicalRefId());
            req.setMedicalStatus(context.getMedicalResult().getStatus());
            req.setMedicalScore(context.getMedicalResult().getMedicalScore());
            req.setMedicalRiskCategory(context.getMedicalResult().getRiskCategory());
            req.setLoadingFactor(context.getMedicalResult().getLoadingFactor());
        }

        // Step 6: Set fields from KYC API response
        if (context.getKycResult() != null) {
            req.setKycStatus(context.getKycResult().getStatus());
        }

        // Step 7: Set fields from Premium API response
        if (context.getPremiumResult() != null) {
            req.setCalculatedPremium(context.getPremiumResult().getCalculatedPremium());
            req.setPremiumFrequency(context.getPremiumResult().getFrequency());
            req.setModalPremium(context.getPremiumResult().getModalPremium());
        }

        // Step 8: Set fields from Underwriting API response
        if (context.getUnderwritingResult() != null) {
            req.setUnderwritingDecision(context.getUnderwritingResult().getDecision());
            req.setUnderwritingDecisionCode(context.getUnderwritingResult().getDecisionCode());
            req.setUnderwritingConditions(context.getUnderwritingResult().getConditions());
            req.setPremiumLoading(context.getUnderwritingResult().getPremiumLoading());
        }

        // Step 9: Set fields from Document API response
        if (context.getDocumentResult() != null) {
            req.setDocumentId(context.getDocumentResult().getDocumentId());
            req.setDocumentUrl(context.getDocumentResult().getDocumentUrl());
        }

        // Step 10: Set fields from Proposal API response
        if (context.getProposalResult() != null) {
            req.setProposalNumber(context.getProposalResult().getProposalNumber());
        }

        return req;
    }
}
