package com.insurance.newbusiness.integration.model.pas;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * PasRequest — sent to PAS (Policy Administration System) to create the application.
 *
 * This is the richest request in the journey because it aggregates data from:
 *   - Partner's raw inbound params (stringvalN via property-file mapping)
 *   - All prior API responses (set manually in PasApiClient.buildPasRequest)
 *
 * FIELD SOURCES:
 *   [RAW]   = from partner's stringvalN, mapped via mapping/default-PAS_API.properties
 *   [RESP]  = from prior API response, set manually in PasApiClient.buildPasRequest()
 *   [CTX]   = from JourneyContext (correlationId, partnerCode)
 *
 * Property file maps RAW fields. RESP fields are set directly in code because
 * they come from typed response objects, not from partner's raw params.
 */
@Data
public class PasRequest {

    // ── Context [CTX] ─────────────────────────────────────────────────────────
    private String correlationId;
    private String partnerCode;

    // ── Applicant details [RAW] — from partner stringvalN ─────────────────────
    private String firstName;
    private String lastName;
    private String middleName;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateOfBirth;

    private String gender;
    private String maritalStatus;
    private String nationality;
    private String mobileNumber;
    private String emailAddress;
    private String panNumber;

    // ── Address [RAW] ─────────────────────────────────────────────────────────
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String state;
    private String pincode;

    // ── Nominee [RAW] ─────────────────────────────────────────────────────────
    private String nomineeName;
    private String nomineeRelationship;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate nomineeDateOfBirth;

    // ── Policy details [RAW] ──────────────────────────────────────────────────
    private String productCode;
    private Integer policyTerm;
    private BigDecimal sumAssured;
    private String paymentMode;           // ANNUAL / SEMI_ANNUAL / QUARTERLY / MONTHLY
    private String smokingStatus;

    // ── From Eligibility API [RESP] ───────────────────────────────────────────
    private String eligibilityId;
    private String eligibilityStatus;
    private Integer ageAtEntry;

    // ── From Scoring APIs [RESP] ──────────────────────────────────────────────
    private Integer creditScore;          // from EDC
    private String creditBureau;          // from EDC
    private Integer pasaScore;            // from PASA
    private String pasaScoreGrade;        // from PASA
    private Integer tasaScore;            // from TASA
    private String tasaRiskCategory;      // from TASA

    // ── From Medical API [RESP] ───────────────────────────────────────────────
    private String medicalRefId;
    private String medicalStatus;
    private Integer medicalScore;
    private String medicalRiskCategory;
    private BigDecimal loadingFactor;

    // ── From KYC API [RESP] ───────────────────────────────────────────────────
    private String kycStatus;

    // ── From Premium API [RESP] ───────────────────────────────────────────────
    private BigDecimal calculatedPremium;
    private String premiumFrequency;
    private BigDecimal modalPremium;

    // ── From Underwriting API [RESP] ──────────────────────────────────────────
    private String underwritingDecision;
    private String underwritingDecisionCode;
    private String underwritingConditions;
    private BigDecimal premiumLoading;

    // ── From Document API [RESP] ──────────────────────────────────────────────
    private String documentId;
    private String documentUrl;

    // ── From Proposal API [RESP] ──────────────────────────────────────────────
    private String proposalNumber;
}
