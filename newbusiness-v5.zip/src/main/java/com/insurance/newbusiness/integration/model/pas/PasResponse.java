package com.insurance.newbusiness.integration.model.pas;

import lombok.Data;

/**
 * PasResponse — received from PAS API after application submission.
 *
 * applicationNumber is the key output — stored in journey_execution
 * and sent to partner via reverse feed.
 */
@Data
public class PasResponse {

    private String applicationNumber;  // the main output — sent to partner via reverse feed
    private String status;             // CREATED / REJECTED / PENDING
    private String policyNumber;       // assigned if auto-issued
    private String remarks;
}
