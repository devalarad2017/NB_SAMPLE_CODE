package com.insurance.newbusiness.domain.dto;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * InboundRequest — maps the actual JSON structure received from partners.
 *
 * Partner sends:
 *   pInObj1_inout, pInObj2_inout, pInObj3_inout : flat maps with stringval1..150
 *   pInList1_inout through pInList6_inout       : lists of dynamic key-value records
 *
 * IMPORTANT: All three pInObj maps have the SAME keys (stringval1..stringval150).
 * getParams() prefixes them as obj1.stringval1, obj2.stringval1, obj3.stringval1
 * so they do NOT overwrite each other when merged into one Map.
 *
 * Mapping properties files use these prefixed keys:
 *   obj1.stringval13=applicantFirstName
 *   obj2.stringval46=height
 */
@Setter
@Getter
@Schema(description = "Insurance application request from external partner")
@JsonIgnoreProperties(ignoreUnknown = true)
public class InboundRequest {

    // ── Flat key-value maps — each has stringval1..150 ────────────────────────
    @JsonProperty("pInObj1_inout")
    private Map<String, String> pInObj1_inout;

    @JsonProperty("pInObj2_inout")
    private Map<String, String> pInObj2_inout;

    @JsonProperty("pInObj3_inout")
    private Map<String, String> pInObj3_inout;

    // ── List objects ──────────────────────────────────────────────────────────
    @JsonProperty("pInList1_inout")
    private PInList pInList1_inout;

    @JsonProperty("pInList4_inout")
    private PInList pInList4_inout;

    @JsonProperty("pInList5_inout")
    private PInList pInList5_inout;

    @JsonProperty("pInList6_inout")
    private PInList pInList6_inout;

    // ── Inner classes ─────────────────────────────────────────────────────────

    @Setter
    @Getter
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class PInList {
        private List<WeoRecStrings150User> WeoRecStrings150User;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class WeoRecStrings150User {
        private Map<String, String> values = new HashMap<>();

        @JsonAnyGetter
        public Map<String, String> getValues() { return values; }

        @JsonAnySetter
        public void setValue(String key, String value) { this.values.put(key, value); }
    }

    // ── Compatibility methods ─────────────────────────────────────────────────

    /**
     * Partner code from pInObj1_inout.stringval1
     * Sample: "TURTLEMINT"
     */
    public String getPartnerCode() {
        return pInObj1_inout != null ? pInObj1_inout.get("stringval1") : null;
    }

    /**
     * Merges all pInObj maps into one Map with PREFIXED keys to avoid collision.
     *
     * pInObj1.stringval13 = "TEST"   → key = "obj1.stringval13"
     * pInObj2.stringval15 = "NOMINEE"→ key = "obj2.stringval15"
     * pInObj3.stringval3  = "12345"  → key = "obj3.stringval3"
     *
     * Empty values are included — MappingService skips them during resolve.
     * This is the Map that JourneyContext stores and MappingService reads from.
     */
    public Map<String, String> getParams() {
        Map<String, String> merged = new LinkedHashMap<>();
        addPrefixed(merged, "obj1", pInObj1_inout);
        addPrefixed(merged, "obj2", pInObj2_inout);
        addPrefixed(merged, "obj3", pInObj3_inout);
        return merged;
    }

    private void addPrefixed(Map<String, String> target, String prefix, Map<String, String> source) {
        if (source == null) return;
        for (Map.Entry<String, String> entry : source.entrySet()) {
            target.put(prefix + "." + entry.getKey(), entry.getValue());
        }
    }

    /**
     * Direct access to a specific pInObj map — for cases where you need
     * to read a value manually without going through mapping properties.
     */
    public Map<String, String> getObj1() { return pInObj1_inout; }
    public Map<String, String> getObj2() { return pInObj2_inout; }
    public Map<String, String> getObj3() { return pInObj3_inout; }
}
