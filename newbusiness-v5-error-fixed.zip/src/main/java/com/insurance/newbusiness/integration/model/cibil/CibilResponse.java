package com.insurance.newbusiness.integration.model.cibil;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

/**
 * CibilResponse — received from CIBIL API after credit bureau check.
 * Fields are populated by RestTemplate deserialization.
 * Used by later stages (scoring, underwriting) for credit data.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CibilResponse {

    private String status;          // SUCCESS / FAIL / BYPASS
    private Integer cibilScore;     // credit score (e.g. 750)
    private String cibilRefId;      // bureau query reference
    private String remarks;
    private Boolean isCibilPass;    // true if score meets threshold
}
