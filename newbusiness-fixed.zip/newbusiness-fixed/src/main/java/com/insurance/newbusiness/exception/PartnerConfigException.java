package com.insurance.newbusiness.exception;

/**
 * Thrown when partner configuration is missing from DB or no notifier is registered.
 */
public class PartnerConfigException extends NewBusinessException {

    public PartnerConfigException(String message) {
        super("PARTNER_CONFIG_ERROR", message);
    }
}
