package com.insurance.newbusiness.mapping;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.insurance.newbusiness.domain.entity.PartnerFieldMapping;
import com.insurance.newbusiness.exception.MappingValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Bridge between partner's generic stringvalN params and typed API request POJOs.
 *
 * How it works:
 *   1. DB table says stringval1 -> firstName, stringval3 -> dateOfBirth, etc.
 *   2. This service resolves those into a Map {"firstName":"John", ...}
 *   3. ObjectMapper.convertValue() turns the Map into the typed POJO
 *
 * CRITICAL: target_field in partner_field_mapping MUST exactly match
 * the Java field name in the POJO class. Both must be camelCase.
 */
@Service
public class ParameterMappingService {

    private static final Logger log = LoggerFactory.getLogger(ParameterMappingService.class);

    @Autowired
    private MappingCache mappingCache;

    @Autowired
    private ObjectMapper objectMapper;

    /**
     * Resolves stringvalN to a typed POJO in one call.
     *
     * Usage:
     *   MedicalRequest req = mappingService.resolveAs(
     *       partnerCode, "MEDICAL_API", rawParams, MedicalRequest.class);
     */
    public <T> T resolveAs(String partnerCode,
                            String targetApi,
                            Map<String, String> rawParams,
                            Class<T> targetClass) {

        Map<String, Object> resolvedMap = resolve(partnerCode, targetApi, rawParams);
        return objectMapper.convertValue(resolvedMap, targetClass);
    }

    /**
     * Returns the resolved Map directly. Normally use resolveAs() instead.
     */
    public Map<String, Object> resolve(String partnerCode,
                                       String targetApi,
                                       Map<String, String> rawParams) {

        List<PartnerFieldMapping> mappings = mappingCache.getMappings(partnerCode, targetApi);

        if (mappings.isEmpty()) {
            log.warn("No mapping rows found — partnerCode={} targetApi={}. " +
                     "Check partner_field_mapping table.", partnerCode, targetApi);
        }

        Map<String, Object> resolved = new LinkedHashMap<>();
        List<String> missingFields = new ArrayList<>();

        for (PartnerFieldMapping mapping : mappings) {

            String rawValue = rawParams.get(mapping.getSourceParam());
            boolean isBlank = (rawValue == null || rawValue.trim().isEmpty());

            // Apply default if partner sent blank
            if (isBlank && isNotBlank(mapping.getDefaultValue())) {
                rawValue = mapping.getDefaultValue();
                isBlank = false;
                log.debug("Default value applied — field={} api={} default={}",
                        mapping.getTargetField(), targetApi, rawValue);
            }

            // Collect ALL missing mandatory fields before throwing
            if (isBlank) {
                if (mapping.isMandatory()) {
                    missingFields.add(
                        mapping.getSourceParam() + " -> " + mapping.getTargetField());
                }
                continue;
            }

            String transformed = applyTransformation(rawValue, mapping.getTransformation());
            Object typed = convertToType(transformed, mapping.getDataType(), mapping.getDateFormat());
            resolved.put(mapping.getTargetField(), typed);
        }

        if (!missingFields.isEmpty()) {
            throw new MappingValidationException(targetApi, missingFields);
        }

        return resolved;
    }

    private String applyTransformation(String value, String transformation) {
        if (transformation == null || transformation.trim().isEmpty()) {
            return value;
        }
        switch (transformation.toUpperCase()) {
            case "TRIM":
                return value.trim();
            case "UPPERCASE":
                return value.trim().toUpperCase();
            case "LOWERCASE":
                return value.trim().toLowerCase();
            default:
                return value;
        }
    }

    private Object convertToType(String value, String dataType, String dateFormat) {
        if (value == null) {
            return null;
        }
        switch (dataType.toUpperCase()) {
            case "STRING":
                return value;
            case "INTEGER":
                return Integer.parseInt(value.trim());
            case "DECIMAL":
                return new BigDecimal(value.trim());
            case "BOOLEAN":
                return Boolean.parseBoolean(value.trim());
            case "DATE":
                DateTimeFormatter fmt = DateTimeFormatter.ofPattern(dateFormat);
                return LocalDate.parse(value.trim(), fmt);
            default:
                log.warn("Unknown dataType '{}' — treating as STRING", dataType);
                return value;
        }
    }

    private boolean isNotBlank(String value) {
        return value != null && !value.trim().isEmpty();
    }
}
