package com.insurance.newbusiness.journey;

import com.insurance.newbusiness.exception.JourneyStageException;
import com.insurance.newbusiness.integration.client.*;
import com.insurance.newbusiness.integration.model.eligibility.EligibilityRequest;
import com.insurance.newbusiness.integration.model.scoring.ScoringRequest;
import com.insurance.newbusiness.integration.model.medical.MedicalRequest;
import com.insurance.newbusiness.integration.model.kyc.KycRequest;
import com.insurance.newbusiness.integration.model.premium.PremiumRequest;
import com.insurance.newbusiness.integration.model.underwriting.UnderwritingRequest;
import com.insurance.newbusiness.integration.model.document.DocumentRequest;
import com.insurance.newbusiness.integration.model.proposal.ProposalRequest;
import com.insurance.newbusiness.mapping.ParameterMappingService;
import com.insurance.newbusiness.tracking.JourneyTrackingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.Executor;

/**
 * Drives the full request processing journey through all stages in order.
 *
 * Stage order:
 *   1. ELIGIBILITY  -> 2. SCORING (parallel EDC+PASA+TASA)  -> 3. MEDICAL
 *   4. KYC  -> 5. PREMIUM  -> 6. UNDERWRITING  -> 7. DOCUMENT  -> 8. PROPOSAL
 *
 * PAS submission and reverse feed are handled in NewBusinessService after this returns.
 *
 * On retry, already-succeeded APIs are skipped and their stored responses
 * are reloaded into JourneyContext so downstream enrichment still works.
 */
@Service
public class JourneyOrchestrator {

    private static final Logger log = LoggerFactory.getLogger(JourneyOrchestrator.class);

    @Autowired private ParameterMappingService mappingService;
    @Autowired private JourneyTrackingService  trackingService;

    @Autowired private EligibilityApiClient  eligibilityClient;
    @Autowired private ScoringApiClient      scoringClient;
    @Autowired private MedicalApiClient      medicalClient;
    @Autowired private KycApiClient          kycClient;
    @Autowired private PremiumApiClient      premiumClient;
    @Autowired private UnderwritingApiClient underwritingClient;
    @Autowired private DocumentApiClient     documentClient;
    @Autowired private ProposalApiClient     proposalClient;

    @Autowired
    @Qualifier("journeyTaskExecutor")
    private Executor taskExecutor;

    /**
     * Runs all stages in order. On retry, succeeded stages are skipped
     * and their stored results are reloaded so downstream enrichment works.
     */
    public void execute(JourneyContext context) {
        Set<String> succeeded = trackingService.getSucceededApiNames(context.getCorrelationId());
        log.info("[{}] Journey started | alreadySucceeded={}", context.getCorrelationId(), succeeded);

        // On retry: reload prior results into context so later stages can read them
        if (!succeeded.isEmpty()) {
            trackingService.reloadStageResults(context, succeeded);
        }

        executeEligibilityStage(context, succeeded);
        executeScoringStage(context, succeeded);
        executeMedicalStage(context, succeeded);
        executeKycStage(context, succeeded);
        executePremiumStage(context, succeeded);
        executeUnderwritingStage(context, succeeded);
        executeDocumentStage(context, succeeded);
        executeProposalStage(context, succeeded);
    }

    // ── Stage 1: ELIGIBILITY ─────────────────────────────────────────────────

    private void executeEligibilityStage(JourneyContext context, Set<String> succeeded) {
        if (succeeded.contains("ELIGIBILITY_API")) {
            log.info("[{}] ELIGIBILITY_API already succeeded — skipping", context.getCorrelationId());
            return;
        }

        EligibilityRequest req = mappingService.resolveAs(
                context.getPartnerCode(), "ELIGIBILITY_API",
                context.getRawParams(), EligibilityRequest.class);

        context.setEligibilityResult(eligibilityClient.call(req, context));

        log.info("[{}] Eligibility done | status={}",
                context.getCorrelationId(), context.getEligibilityResult().getStatus());
    }

    // ── Stage 2: SCORING (EDC + PASA + TASA in parallel) ─────────────────────

    private void executeScoringStage(JourneyContext context, Set<String> succeeded) {
        boolean edcDone  = succeeded.contains("EDC_API");
        boolean pasaDone = succeeded.contains("PASA_API");
        boolean tasaDone = succeeded.contains("TASA_API");

        if (edcDone && pasaDone && tasaDone) {
            log.info("[{}] All scoring APIs already succeeded — skipping", context.getCorrelationId());
            return;
        }

        ScoringRequest req = mappingService.resolveAs(
                context.getPartnerCode(), "SCORING_API",
                context.getRawParams(), ScoringRequest.class);

        CompletableFuture<Void> edcFuture = edcDone
                ? CompletableFuture.completedFuture(null)
                : CompletableFuture.runAsync(() ->
                    context.setEdcResult(scoringClient.callEdc(req, context)), taskExecutor);

        CompletableFuture<Void> pasaFuture = pasaDone
                ? CompletableFuture.completedFuture(null)
                : CompletableFuture.runAsync(() ->
                    context.setPasaResult(scoringClient.callPasa(req, context)), taskExecutor);

        CompletableFuture<Void> tasaFuture = tasaDone
                ? CompletableFuture.completedFuture(null)
                : CompletableFuture.runAsync(() ->
                    context.setTasaResult(scoringClient.callTasa(req, context)), taskExecutor);

        // join() wraps exceptions in CompletionException — unwrap before rethrowing
        try {
            CompletableFuture.allOf(edcFuture, pasaFuture, tasaFuture).join();
        } catch (CompletionException ex) {
            Throwable cause = ex.getCause();
            if (cause instanceof JourneyStageException) {
                throw (JourneyStageException) cause;
            }
            if (cause instanceof RuntimeException) {
                throw (RuntimeException) cause;
            }
            throw new JourneyStageException("SCORING_STAGE",
                    "Parallel scoring failed: " + cause.getMessage());
        }

        log.info("[{}] Scoring done | edc={} pasa={} tasa={}",
                context.getCorrelationId(),
                context.getEdcResult()  != null ? context.getEdcResult().getStatus()      : "skipped",
                context.getPasaResult() != null ? context.getPasaResult().getScoreGrade() : "skipped",
                context.getTasaResult() != null ? context.getTasaResult().getRiskCategory(): "skipped");
    }

    // ── Stage 3: MEDICAL ─────────────────────────────────────────────────────

    private void executeMedicalStage(JourneyContext context, Set<String> succeeded) {
        if (succeeded.contains("MEDICAL_API")) {
            log.info("[{}] MEDICAL_API already succeeded — skipping", context.getCorrelationId());
            return;
        }

        MedicalRequest req = mappingService.resolveAs(
                context.getPartnerCode(), "MEDICAL_API",
                context.getRawParams(), MedicalRequest.class);

        if (context.getEligibilityResult() != null) {
            req.setEligibilityId(context.getEligibilityResult().getEligibilityId());
            req.setAgeAtEntry(context.getEligibilityResult().getAgeAtEntry());
        }
        if (context.getEdcResult() != null) {
            req.setCreditScore(context.getEdcResult().getCreditScore());
        }

        context.setMedicalResult(medicalClient.call(req, context));

        log.info("[{}] Medical done | status={} score={}",
                context.getCorrelationId(),
                context.getMedicalResult().getStatus(),
                context.getMedicalResult().getMedicalScore());
    }

    // ── Stage 4: KYC ─────────────────────────────────────────────────────────

    private void executeKycStage(JourneyContext context, Set<String> succeeded) {
        if (succeeded.contains("KYC_API")) {
            log.info("[{}] KYC_API already succeeded — skipping", context.getCorrelationId());
            return;
        }

        KycRequest req = mappingService.resolveAs(
                context.getPartnerCode(), "KYC_API",
                context.getRawParams(), KycRequest.class);

        context.setKycResult(kycClient.call(req, context));

        log.info("[{}] KYC done | status={}", context.getCorrelationId(),
                context.getKycResult().getStatus());
    }

    // ── Stage 5: PREMIUM CALCULATION ─────────────────────────────────────────

    private void executePremiumStage(JourneyContext context, Set<String> succeeded) {
        if (succeeded.contains("PREMIUM_API")) {
            log.info("[{}] PREMIUM_API already succeeded — skipping", context.getCorrelationId());
            return;
        }

        PremiumRequest req = mappingService.resolveAs(
                context.getPartnerCode(), "PREMIUM_CALC_API",
                context.getRawParams(), PremiumRequest.class);

        if (context.getEligibilityResult() != null) {
            req.setAgeAtEntry(context.getEligibilityResult().getAgeAtEntry());
        }
        if (context.getMedicalResult() != null) {
            req.setRiskCategory(context.getMedicalResult().getRiskCategory());
            req.setLoadingFactor(context.getMedicalResult().getLoadingFactor());
        }

        context.setPremiumResult(premiumClient.call(req, context));

        log.info("[{}] Premium done | premium={} frequency={}",
                context.getCorrelationId(),
                context.getPremiumResult().getCalculatedPremium(),
                context.getPremiumResult().getFrequency());
    }

    // ── Stage 6: UNDERWRITING ────────────────────────────────────────────────

    private void executeUnderwritingStage(JourneyContext context, Set<String> succeeded) {
        if (succeeded.contains("UNDERWRITING_API")) {
            log.info("[{}] UNDERWRITING_API already succeeded — skipping", context.getCorrelationId());
            return;
        }

        UnderwritingRequest req = mappingService.resolveAs(
                context.getPartnerCode(), "UNDERWRITING_API",
                context.getRawParams(), UnderwritingRequest.class);

        if (context.getEdcResult() != null) {
            req.setCreditScore(context.getEdcResult().getCreditScore());
        }
        if (context.getPasaResult() != null) {
            req.setPasaScore(context.getPasaResult().getPasaScore());
        }
        if (context.getTasaResult() != null) {
            req.setTasaRiskCategory(context.getTasaResult().getRiskCategory());
        }
        if (context.getMedicalResult() != null) {
            req.setMedicalScore(context.getMedicalResult().getMedicalScore());
            req.setMedicalRiskCategory(context.getMedicalResult().getRiskCategory());
            req.setLoadingFactor(context.getMedicalResult().getLoadingFactor());
        }

        context.setUnderwritingResult(underwritingClient.call(req, context));

        if ("DECLINED".equalsIgnoreCase(context.getUnderwritingResult().getDecision())) {
            log.warn("[{}] Underwriting DECLINED — stopping journey", context.getCorrelationId());
            throw new JourneyStageException("UNDERWRITING_STAGE",
                    "Application declined: " + context.getUnderwritingResult().getDecisionCode());
        }

        log.info("[{}] Underwriting done | decision={}",
                context.getCorrelationId(), context.getUnderwritingResult().getDecision());
    }

    // ── Stage 7: DOCUMENT GENERATION ─────────────────────────────────────────

    private void executeDocumentStage(JourneyContext context, Set<String> succeeded) {
        if (succeeded.contains("DOCUMENT_API")) {
            log.info("[{}] DOCUMENT_API already succeeded — skipping", context.getCorrelationId());
            return;
        }

        DocumentRequest req = mappingService.resolveAs(
                context.getPartnerCode(), "DOCUMENT_API",
                context.getRawParams(), DocumentRequest.class);

        req.setCorrelationId(context.getCorrelationId());

        context.setDocumentResult(documentClient.call(req, context));

        log.info("[{}] Document done | documentId={}",
                context.getCorrelationId(), context.getDocumentResult().getDocumentId());
    }

    // ── Stage 8: PROPOSAL SUBMISSION ─────────────────────────────────────────

    private void executeProposalStage(JourneyContext context, Set<String> succeeded) {
        if (succeeded.contains("PROPOSAL_API")) {
            log.info("[{}] PROPOSAL_API already succeeded — skipping", context.getCorrelationId());
            return;
        }

        ProposalRequest req = mappingService.resolveAs(
                context.getPartnerCode(), "PROPOSAL_SUBMIT_API",
                context.getRawParams(), ProposalRequest.class);

        if (context.getPremiumResult() != null) {
            req.setCalculatedPremium(context.getPremiumResult().getCalculatedPremium());
            req.setFrequency(context.getPremiumResult().getFrequency());
        }
        if (context.getUnderwritingResult() != null) {
            req.setUnderwritingDecision(context.getUnderwritingResult().getDecision());
        }
        if (context.getDocumentResult() != null) {
            req.setDocumentId(context.getDocumentResult().getDocumentId());
        }

        context.setProposalResult(proposalClient.call(req, context));

        log.info("[{}] Proposal done | proposalNumber={}",
                context.getCorrelationId(), context.getProposalResult().getProposalNumber());
    }
}
