package com.insurance.newbusiness.tracking;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.insurance.newbusiness.domain.entity.JourneyExecution;
import com.insurance.newbusiness.domain.entity.JourneyStageLog;
import com.insurance.newbusiness.integration.model.document.DocumentResponse;
import com.insurance.newbusiness.integration.model.eligibility.EligibilityResponse;
import com.insurance.newbusiness.integration.model.kyc.KycResponse;
import com.insurance.newbusiness.integration.model.medical.MedicalResponse;
import com.insurance.newbusiness.integration.model.premium.PremiumResponse;
import com.insurance.newbusiness.integration.model.proposal.ProposalResponse;
import com.insurance.newbusiness.integration.model.scoring.EdcResponse;
import com.insurance.newbusiness.integration.model.scoring.PasaResponse;
import com.insurance.newbusiness.integration.model.scoring.TasaResponse;
import com.insurance.newbusiness.integration.model.underwriting.UnderwritingResponse;
import com.insurance.newbusiness.journey.JourneyContext;
import com.insurance.newbusiness.repository.JourneyExecutionRepository;
import com.insurance.newbusiness.repository.JourneyStageLogRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

/**
 * All writes/reads for journey_execution and journey_stage_log.
 *
 * CRITICAL RULE: Every method catches its own exceptions internally.
 * Tracking must NEVER stop or affect the journey processing.
 * If a DB write fails, it logs to file and returns silently.
 */
@Service
public class JourneyTrackingService {

    private static final Logger log = LoggerFactory.getLogger(JourneyTrackingService.class);

    @Autowired private JourneyExecutionRepository executionRepository;
    @Autowired private JourneyStageLogRepository  stageLogRepository;
    @Autowired private ObjectMapper               objectMapper;

    /** Creates the initial journey_execution record when a new request arrives. */
    public void initJourney(JourneyContext context, Long rawRequestId) {
        try {
            JourneyExecution execution = new JourneyExecution();
            execution.setCorrelationId(context.getCorrelationId());
            execution.setPartnerCode(context.getPartnerCode());
            execution.setRawRequestId(rawRequestId);
            execution.setOverallStatus("IN_PROGRESS");
            executionRepository.save(execution);
        } catch (Exception ex) {
            log.error("[{}] Failed to init journey_execution: {}",
                    context.getCorrelationId(), ex.getMessage());
        }
    }

    /**
     * Returns set of apiNames that already have status=SUCCESS.
     * Used by orchestrator to skip completed stages on retry.
     */
    public Set<String> getSucceededApiNames(String correlationId) {
        try {
            Set<String> names = stageLogRepository.findSucceededApiNames(correlationId);
            return names != null ? names : Collections.emptySet();
        } catch (Exception ex) {
            log.error("[{}] Failed to load succeeded api names — treating as fresh: {}",
                    correlationId, ex.getMessage());
            return Collections.emptySet();
        }
    }

    /**
     * Reloads stored response payloads into JourneyContext for already-succeeded APIs.
     * This is essential on retry — without it, downstream stages that read prior
     * results (e.g. MEDICAL reading ELIGIBILITY's eligibilityId) would get nulls.
     */
    public void reloadStageResults(JourneyContext context, Set<String> succeededApis) {
        try {
            List<JourneyStageLog> logs = stageLogRepository.findSucceededLogs(context.getCorrelationId());

            // Deduplicate: keep only the latest SUCCESS entry per apiName
            Set<String> loaded = new HashSet<>();
            for (JourneyStageLog entry : logs) {
                String apiName = entry.getApiName();
                if (loaded.contains(apiName) || entry.getResponsePayload() == null) {
                    continue;
                }
                loaded.add(apiName);

                try {
                    reloadSingleResult(context, apiName, entry.getResponsePayload());
                } catch (Exception ex) {
                    log.warn("[{}] Could not reload {} response — downstream enrichment may be partial: {}",
                            context.getCorrelationId(), apiName, ex.getMessage());
                }
            }

            log.info("[{}] Reloaded {} stage results for retry: {}",
                    context.getCorrelationId(), loaded.size(), loaded);

        } catch (Exception ex) {
            log.error("[{}] Failed to reload stage results — journey continues without them: {}",
                    context.getCorrelationId(), ex.getMessage());
        }
    }

    /**
     * Deserializes one stored response payload back into the correct typed object
     * and sets it on the JourneyContext.
     */
    private void reloadSingleResult(JourneyContext context, String apiName, String responseJson) throws Exception {
        switch (apiName) {
            case "ELIGIBILITY_API":
                context.setEligibilityResult(objectMapper.readValue(responseJson, EligibilityResponse.class));
                break;
            case "EDC_API":
                context.setEdcResult(objectMapper.readValue(responseJson, EdcResponse.class));
                break;
            case "PASA_API":
                context.setPasaResult(objectMapper.readValue(responseJson, PasaResponse.class));
                break;
            case "TASA_API":
                context.setTasaResult(objectMapper.readValue(responseJson, TasaResponse.class));
                break;
            case "MEDICAL_API":
                context.setMedicalResult(objectMapper.readValue(responseJson, MedicalResponse.class));
                break;
            case "KYC_API":
                context.setKycResult(objectMapper.readValue(responseJson, KycResponse.class));
                break;
            case "PREMIUM_API":
                context.setPremiumResult(objectMapper.readValue(responseJson, PremiumResponse.class));
                break;
            case "UNDERWRITING_API":
                context.setUnderwritingResult(objectMapper.readValue(responseJson, UnderwritingResponse.class));
                break;
            case "DOCUMENT_API":
                context.setDocumentResult(objectMapper.readValue(responseJson, DocumentResponse.class));
                break;
            case "PROPOSAL_API":
                context.setProposalResult(objectMapper.readValue(responseJson, ProposalResponse.class));
                break;
            default:
                log.debug("[{}] No reload handler for apiName={}", context.getCorrelationId(), apiName);
        }
    }

    /** Marks journey as COMPLETED and stores the applicationNumber. */
    public void markJourneyCompleted(JourneyContext context) {
        try {
            executionRepository.findByCorrelationId(context.getCorrelationId())
                    .ifPresent(execution -> {
                        execution.setOverallStatus("COMPLETED");
                        execution.setApplicationNumber(context.getApplicationNumber());
                        executionRepository.save(execution);
                    });
        } catch (Exception ex) {
            log.error("[{}] Failed to mark journey completed: {}",
                    context.getCorrelationId(), ex.getMessage());
        }
    }

    /** Marks journey as FAILED so a retry job can pick it up later. */
    public void markJourneyFailed(JourneyContext context, String errorMessage) {
        try {
            executionRepository.findByCorrelationId(context.getCorrelationId())
                    .ifPresent(execution -> {
                        execution.setOverallStatus("FAILED");
                        executionRepository.save(execution);
                    });
        } catch (Exception ex) {
            log.error("[{}] Failed to mark journey failed: {}",
                    context.getCorrelationId(), ex.getMessage());
        }
    }

    /**
     * Logs one API call attempt. Called by every ApiClient on every call.
     * On retry, a new row is inserted — previous rows remain as audit history.
     * This table is append-only, never updated.
     */
    public void logApiCall(JourneyContext context,
                            String stageName,
                            String apiName,
                            Object request,
                            Object response,
                            String status,
                            String errorCode,
                            String errorMessage,
                            long durationMs) {
        try {
            JourneyStageLog entry = new JourneyStageLog();
            entry.setCorrelationId(context.getCorrelationId());
            entry.setStageName(stageName);
            entry.setApiName(apiName);
            entry.setRequestPayload(toJson(request));
            entry.setResponsePayload(toJson(response));
            entry.setStatus(status);
            entry.setErrorCode(errorCode);
            entry.setErrorMessage(errorMessage);
            entry.setDurationMs(durationMs);
            entry.setExecutedAt(LocalDateTime.now());
            stageLogRepository.save(entry);
        } catch (Exception ex) {
            log.error("[{}] Failed to write stage log [{}/{}]: {}",
                    context.getCorrelationId(), stageName, apiName, ex.getMessage());
        }
    }

    private String toJson(Object obj) {
        if (obj == null) return null;
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (Exception ex) {
            return "[serialization-error: " + ex.getMessage() + "]";
        }
    }
}
