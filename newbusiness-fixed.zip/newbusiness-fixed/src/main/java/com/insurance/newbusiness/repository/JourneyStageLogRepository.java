package com.insurance.newbusiness.repository;

import com.insurance.newbusiness.domain.entity.JourneyStageLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Set;

public interface JourneyStageLogRepository extends JpaRepository<JourneyStageLog, Long> {

    /**
     * Returns API names that have succeeded for this correlationId.
     * Used by JourneyOrchestrator to skip already-completed steps on retry.
     */
    @Query("SELECT l.apiName FROM JourneyStageLog l " +
           "WHERE l.correlationId = :correlationId AND l.status = 'SUCCESS'")
    Set<String> findSucceededApiNames(@Param("correlationId") String correlationId);

    /**
     * Returns the most recent SUCCESS log entry per API for this correlationId.
     * Used to reload response payloads into JourneyContext on retry.
     */
    @Query("SELECT l FROM JourneyStageLog l " +
           "WHERE l.correlationId = :correlationId AND l.status = 'SUCCESS' " +
           "ORDER BY l.executedAt DESC")
    List<JourneyStageLog> findSucceededLogs(@Param("correlationId") String correlationId);
}
