package com.insurance.newbusiness.mapping;

import com.insurance.newbusiness.domain.entity.PartnerFieldMapping;
import com.insurance.newbusiness.repository.PartnerFieldMappingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.*;

/**
 * Loads ALL active rows from partner_field_mapping at startup and caches them.
 *
 * Cache key:   "partnerCode::targetApi"
 * Cache value:  List of mapping rows for that combination
 *
 * Zero DB calls per request — everything resolved from memory.
 * Restart the app after adding new mapping rows to DB.
 */
@Component
class MappingCache {

    private static final Logger log = LoggerFactory.getLogger(MappingCache.class);

    @Autowired
    private PartnerFieldMappingRepository repository;

    private final Map<String, List<PartnerFieldMapping>> cache = new HashMap<>();

    @PostConstruct
    public void load() {
        List<PartnerFieldMapping> all = repository.findByActiveTrue();
        cache.clear();
        for (PartnerFieldMapping m : all) {
            String key = buildKey(m.getPartnerCode(), m.getTargetApi());
            cache.computeIfAbsent(key, k -> new ArrayList<>()).add(m);
        }
        log.info("MappingCache loaded — {} partner+api combinations | {} total rows",
                cache.size(), all.size());
    }

    public List<PartnerFieldMapping> getMappings(String partnerCode, String targetApi) {
        List<PartnerFieldMapping> mappings = cache.get(buildKey(partnerCode, targetApi));
        return mappings != null ? mappings : Collections.emptyList();
    }

    private String buildKey(String partnerCode, String targetApi) {
        return partnerCode + "::" + targetApi;
    }
}
