package com.insurance.newbusiness.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.insurance.newbusiness.domain.dto.InboundRequest;
import com.insurance.newbusiness.domain.entity.RawRequest;
import com.insurance.newbusiness.exception.PartnerConfigException;
import com.insurance.newbusiness.journey.JourneyContext;
import com.insurance.newbusiness.journey.JourneyOrchestrator;
import com.insurance.newbusiness.pas.PasApiClient;
import com.insurance.newbusiness.repository.RawRequestRepository;
import com.insurance.newbusiness.reversefeed.PartnerNotifierFactory;
import com.insurance.newbusiness.tracking.JourneyTrackingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.Map;
import java.util.UUID;

/**
 * Top-level coordinator. Two methods, two threads:
 *
 * receiveAndAcknowledge() — HTTP thread, fast, returns correlationId immediately.
 * processJourney()        — background thread (@Async), partner already got 202.
 */
@Service
public class NewBusinessService {

    private static final Logger log = LoggerFactory.getLogger(NewBusinessService.class);

    @Autowired private RawRequestRepository  rawRequestRepository;
    @Autowired private JourneyTrackingService trackingService;
    @Autowired private JourneyOrchestrator   journeyOrchestrator;
    @Autowired private PasApiClient          pasApiClient;
    @Autowired private PartnerNotifierFactory notifierFactory;
    @Autowired private ObjectMapper          objectMapper;

    // Self-injection via proxy — required so @Async on processJourney() works.
    // Direct this.processJourney() call bypasses AOP proxy and runs synchronously.
    @Lazy
    @Autowired
    private NewBusinessService self;

    /**
     * SYNC — runs on HTTP thread. Must be fast.
     * Validates, persists raw request, triggers async journey, returns correlationId.
     */
    @Transactional
    public String receiveAndAcknowledge(InboundRequest inboundRequest) {
        // Validate input before doing anything
        validateRequest(inboundRequest);

        String correlationId = UUID.randomUUID().toString();
        MDC.put("correlationId", correlationId);

        log.info("[{}] Request received | partner={}",
                correlationId, inboundRequest.getPartnerCode());

        // Store raw payload — immutable snapshot of what partner sent
        RawRequest rawRequest = new RawRequest();
        rawRequest.setCorrelationId(correlationId);
        rawRequest.setPartnerCode(inboundRequest.getPartnerCode());
        rawRequest.setRawPayload(toJson(inboundRequest.getParams()));
        rawRequestRepository.save(rawRequest);

        // Build context for the full journey
        Map<String, String> params = inboundRequest.getParams() != null
                ? inboundRequest.getParams()
                : Collections.emptyMap();

        JourneyContext context = new JourneyContext(
                correlationId,
                inboundRequest.getPartnerCode(),
                params);

        // Create journey_execution row — IN_PROGRESS
        trackingService.initJourney(context, rawRequest.getId());

        // Fire async via proxy — HTTP thread returns here immediately
        self.processJourney(context);

        return correlationId;
    }

    /**
     * ASYNC — runs on journeyTaskExecutor. Partner already got 202.
     */
    @Async("journeyTaskExecutor")
    public void processJourney(JourneyContext context) {
        try {
            MDC.put("correlationId", context.getCorrelationId());

            // Stages 1-8: eligibility -> scoring -> medical -> kyc
            //              -> premium -> underwriting -> document -> proposal
            journeyOrchestrator.execute(context);

            // Stage 9: PAS submission — returns applicationNumber
            String applicationNumber = pasApiClient.submitAndGetApplicationNumber(context);
            context.setApplicationNumber(applicationNumber);

            // Store applicationNumber and mark COMPLETED
            trackingService.markJourneyCompleted(context);

            // Stage 10: Reverse feed — push applicationNumber to partner callback
            notifierFactory
                    .getNotifier(context.getPartnerCode())
                    .notify(context, applicationNumber);

            log.info("[{}] Journey COMPLETED | applicationNumber={}",
                    context.getCorrelationId(), applicationNumber);

        } catch (Exception ex) {
            trackingService.markJourneyFailed(context, ex.getMessage());
            log.error("[{}] Journey FAILED: {}",
                    context.getCorrelationId(), ex.getMessage(), ex);
            // Don't rethrow — @Async methods that throw cause unhandled exception warnings
        } finally {
            MDC.clear();
        }
    }

    private void validateRequest(InboundRequest request) {
        if (request == null) {
            throw new PartnerConfigException("Request body is null");
        }
        if (request.getPartnerCode() == null || request.getPartnerCode().trim().isEmpty()) {
            throw new PartnerConfigException("partnerCode is required");
        }
        if (request.getParams() == null || request.getParams().isEmpty()) {
            throw new PartnerConfigException("params map is required and cannot be empty");
        }
    }

    private String toJson(Object obj) {
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            return "[serialization-error]";
        }
    }
}
