package com.insurance.newbusiness.exception;

import java.util.List;

/**
 * Thrown when mandatory partner field mappings are missing or blank.
 * Collects ALL missing fields before throwing — easier to debug during integration.
 */
public class MappingValidationException extends NewBusinessException {

    private final List<String> missingFields;

    public MappingValidationException(String targetApi, List<String> missingFields) {
        super("MAPPING_ERROR",
              "Mandatory fields missing for [" + targetApi + "]: " + missingFields);
        this.missingFields = missingFields;
    }

    public List<String> getMissingFields() {
        return missingFields;
    }
}
