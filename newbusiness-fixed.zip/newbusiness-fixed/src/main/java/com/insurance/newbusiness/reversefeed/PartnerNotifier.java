package com.insurance.newbusiness.reversefeed;

import com.insurance.newbusiness.journey.JourneyContext;

/**
 * Contract for sending reverse feed notifications to a partner.
 * Each partner gets its own implementation.
 */
public interface PartnerNotifier {

    String getSupportedPartnerCode();

    void notify(JourneyContext context, String applicationNumber);
}
