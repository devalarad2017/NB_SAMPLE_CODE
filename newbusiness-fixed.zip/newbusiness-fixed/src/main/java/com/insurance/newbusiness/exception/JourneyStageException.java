package com.insurance.newbusiness.exception;

/**
 * Thrown when all retries for a journey stage are exhausted.
 * This stops the journey — the orchestrator catches it and marks the journey as FAILED.
 */
public class JourneyStageException extends NewBusinessException {

    private final String stageName;

    public JourneyStageException(String stageName, String message) {
        super("JOURNEY_STAGE_ERROR", "Stage [" + stageName + "] failed: " + message);
        this.stageName = stageName;
    }

    public String getStageName() {
        return stageName;
    }
}
