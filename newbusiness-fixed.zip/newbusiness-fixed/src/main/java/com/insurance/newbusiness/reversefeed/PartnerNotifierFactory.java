package com.insurance.newbusiness.reversefeed;

import com.insurance.newbusiness.exception.PartnerConfigException;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Registry of all PartnerNotifier beans.
 *
 * Spring auto-collects all PartnerNotifier implementations into the list.
 * Adding a new partner = add a new @Component implementing PartnerNotifier.
 */
@Service
public class PartnerNotifierFactory {

    private final Map<String, PartnerNotifier> notifiers = new HashMap<>();

    public PartnerNotifierFactory(List<PartnerNotifier> notifierList) {
        for (PartnerNotifier notifier : notifierList) {
            notifiers.put(notifier.getSupportedPartnerCode(), notifier);
        }
    }

    public PartnerNotifier getNotifier(String partnerCode) {
        PartnerNotifier notifier = notifiers.get(partnerCode);
        if (notifier == null) {
            throw new PartnerConfigException(
                    "No PartnerNotifier for partnerCode: " + partnerCode +
                    ". Add a @Component implementing PartnerNotifier.");
        }
        return notifier;
    }
}
