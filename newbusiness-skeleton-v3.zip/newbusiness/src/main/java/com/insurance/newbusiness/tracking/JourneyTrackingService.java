package com.insurance.newbusiness.tracking;

import com.insurance.newbusiness.domain.entity.JourneyExecution;
import com.insurance.newbusiness.domain.entity.JourneyStageLog;
import com.insurance.newbusiness.journey.JourneyContext;
import com.insurance.newbusiness.repository.JourneyExecutionRepository;
import com.insurance.newbusiness.repository.JourneyStageLogRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Set;

/**
 * JourneyTrackingService — all writes to journey_execution and journey_stage_log.
 *
 * CRITICAL RULE: Every method catches its own exceptions internally.
 * Tracking must NEVER stop the journey. If a DB write fails,
 * it logs the error to file and returns silently. Journey continues.
 *
 * journey_stage_log is the source of truth for retry/resume.
 * getSucceededApiNames() is called by JourneyOrchestrator before each run
 * to find which API steps to skip.
 */
@Service
public class JourneyTrackingService {

    private static final Logger log = LoggerFactory.getLogger(JourneyTrackingService.class);

    @Autowired private JourneyExecutionRepository executionRepository;
    @Autowired private JourneyStageLogRepository  stageLogRepository;

    /**
     * Creates the journey_execution record when a new request arrives.
     * Called once from NewBusinessService after raw request is stored.
     */
    public void initJourney(JourneyContext context, Long rawRequestId) {
        try {
            JourneyExecution execution = new JourneyExecution();
            execution.setCorrelationId(context.getCorrelationId());
            execution.setPartnerCode(context.getPartnerCode());
            execution.setRawRequestId(rawRequestId);
            execution.setOverallStatus("IN_PROGRESS");
            executionRepository.save(execution);
        } catch (Exception ex) {
            log.error("[{}] Failed to init journey_execution: {}",
                    context.getCorrelationId(), ex.getMessage());
        }
    }

    /**
     * Returns set of api_names with status=SUCCESS in journey_stage_log.
     * JourneyOrchestrator uses this to skip already-completed steps on retry.
     * Returns empty set if this is a fresh journey (no prior attempts).
     */
    public Set<String> getSucceededApiNames(String correlationId) {
        try {
            return stageLogRepository.findSucceededApiNames(correlationId);
        } catch (Exception ex) {
            log.error("[{}] Failed to load succeeded api names: {}", correlationId, ex.getMessage());
            return Collections.emptySet();
        }
    }

    /**
     * Marks a stage as started — updates overall_status to IN_PROGRESS.
     */
    public void markStageStarted(JourneyContext context, String stageName) {
        try {
            executionRepository.findByCorrelationId(context.getCorrelationId())
                    .ifPresent(execution -> {
                        execution.setOverallStatus("IN_PROGRESS");
                        executionRepository.save(execution);
                    });
        } catch (Exception ex) {
            log.error("[{}] Failed to mark stage started [{}]: {}",
                    context.getCorrelationId(), stageName, ex.getMessage());
        }
    }

    /**
     * Marks a stage as completed. No DB column update needed —
     * individual API SUCCESS records in journey_stage_log serve as proof.
     */
    public void markStageCompleted(JourneyContext context, String stageName) {
        log.debug("[{}] Stage completed: {}", context.getCorrelationId(), stageName);
        // journey_stage_log SUCCESS records per api_name are the source of truth.
        // No extra column write needed here.
    }

    /**
     * Marks the full journey as COMPLETED and stores the application number.
     */
    public void markJourneyCompleted(JourneyContext context) {
        try {
            executionRepository.findByCorrelationId(context.getCorrelationId())
                    .ifPresent(execution -> {
                        execution.setOverallStatus("COMPLETED");
                        execution.setApplicationNumber(context.getApplicationNumber());
                        executionRepository.save(execution);
                    });
        } catch (Exception ex) {
            log.error("[{}] Failed to mark journey completed: {}",
                    context.getCorrelationId(), ex.getMessage());
        }
    }

    /**
     * Logs one API call attempt to journey_stage_log.
     * Called by ApiExecutor for EVERY call — success and failure.
     * attempt_number increments per retry so all attempts are visible.
     *
     * This is the core audit trail. Never update — only insert.
     */
    public void logApiCall(JourneyContext context,
                           String stageName,
                           String apiName,
                           String requestPayload,
                           String responsePayload,
                           String status,
                           String errorCode,
                           String errorMessage,
                           long durationMs) {
        try {
            JourneyStageLog entry = new JourneyStageLog();
            entry.setCorrelationId(context.getCorrelationId());
            entry.setStageName(stageName);
            entry.setApiName(apiName);
            entry.setRequestPayload(requestPayload);
            entry.setResponsePayload(responsePayload);
            entry.setStatus(status);
            entry.setErrorCode(errorCode);
            entry.setErrorMessage(errorMessage);
            entry.setDurationMs(durationMs);
            entry.setExecutedAt(LocalDateTime.now());
            stageLogRepository.save(entry);
        } catch (Exception ex) {
            log.error("[{}] Failed to write stage log for [{}]: {}",
                    context.getCorrelationId(), apiName, ex.getMessage());
        }
    }
}
