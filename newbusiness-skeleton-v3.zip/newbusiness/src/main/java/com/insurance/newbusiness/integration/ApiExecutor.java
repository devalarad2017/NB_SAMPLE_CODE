package com.insurance.newbusiness.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.insurance.newbusiness.exception.ApiCallException;
import com.insurance.newbusiness.exception.JourneyStageException;
import com.insurance.newbusiness.journey.ApiStep;
import com.insurance.newbusiness.journey.JourneyContext;
import com.insurance.newbusiness.mapping.ParameterMappingService;
import com.insurance.newbusiness.tracking.JourneyTrackingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

/**
 * ApiExecutor — ONE class handles ALL downstream API calls.
 *
 * WHY ONE CLASS:
 *   Every API call does the same things: resolve params, build request,
 *   post to URL, handle response, log everything, retry on failure.
 *   Only the URL and request structure differ — both are configurable.
 *   Having one class per API would create 20 near-identical files.
 *
 * FLAT vs NESTED REQUEST:
 *   Flat  — ApiStep has no RequestBuilder. ApiExecutor posts the resolved
 *            Map<String,Object> directly. RestTemplate serialises to flat JSON.
 *
 *   Nested — ApiStep has a RequestBuilder lambda. ApiExecutor calls it to get
 *            a POJO (e.g. MedicalApiRequest), then posts the POJO.
 *            RestTemplate serialises POJO to nested JSON automatically.
 *            Create a POJO only when the downstream API needs nested JSON.
 *
 * RESPONSE:
 *   Always received as Map<String,Object>. ApiExecutor stores in context.stageResults.
 *   PostProcessor on ApiStep extracts specific fields into context.enrichedParams
 *   so the next API step can use them.
 *
 * RETRY:
 *   @Retryable retries 3 times on ApiCallException with exponential backoff.
 *   Each attempt is logged to journey_stage_log separately.
 *   After 3 failures @Recover throws JourneyStageException — stops the journey.
 *   On next retry JourneyOrchestrator skips already-succeeded APIs and runs this one.
 *
 * NOTE ON @Retryable + AOP:
 *   @Retryable works via Spring AOP proxy. execute() must be called from OUTSIDE
 *   this bean (JourneyOrchestrator calls apiExecutor.execute()) — this is correct.
 *   Calling execute() from within this class bypasses the proxy and retry won't work.
 */
@Service
public class ApiExecutor {

    private static final Logger log = LoggerFactory.getLogger(ApiExecutor.class);

    @Autowired private RestTemplate restTemplate;
    @Autowired private ParameterMappingService mappingService;
    @Autowired private JourneyTrackingService trackingService;
    @Autowired private ObjectMapper objectMapper;

    // Loaded from application.yml: api.endpoints.EDC_API, api.endpoints.MEDICAL_API etc.
    // Key must exactly match the apiName string used in JourneyOrchestrator ApiStep definitions.
    @Value("#{${api.endpoints}}")
    private Map<String, String> apiEndpoints;

    /**
     * Executes one API call. Retried up to 3 times on ApiCallException.
     *
     * @param step      ApiStep config — holds apiName, RequestBuilder, PostProcessor
     * @param stageName parent stage name — used only for tracking log
     * @param context   shared journey state — rawParams, enrichedParams, correlationId
     * @return response body as Map<String, Object>
     */
    @Retryable(
            value = {ApiCallException.class},
            maxAttempts = 3,
            backoff = @Backoff(delay = 2000, multiplier = 2)
    )
    public Map<String, Object> execute(ApiStep step, String stageName, JourneyContext context) {
        long startTime = System.currentTimeMillis();
        String apiName = step.getApiName();

        // Step 1: Resolve typed params from mapping table
        Map<String, Object> resolvedParams = mappingService.resolve(
                context.getPartnerCode(),
                apiName,
                context.getRawParams(),
                context.getEnrichedParams()
        );

        // Step 2: Build request body
        //   Flat  API — post the resolvedParams Map directly
        //   Nested API — call RequestBuilder to convert Map into POJO
        Object requestBody = step.hasRequestBuilder()
                ? step.getRequestBuilder().build(resolvedParams)
                : resolvedParams;

        String requestJson = toJson(requestBody);

        log.info("[{}] Calling {} | stage={}", context.getCorrelationId(), apiName, stageName);

        try {
            // Step 3: POST request — RestTemplate serialises requestBody to JSON
            String url = getEndpointUrl(apiName);
            ResponseEntity<Map> response = restTemplate.postForEntity(url, requestBody, Map.class);

            @SuppressWarnings("unchecked")
            Map<String, Object> responseBody = response.getBody();
            long duration = System.currentTimeMillis() - startTime;

            // Step 4: Log SUCCESS
            trackingService.logApiCall(context, stageName, apiName,
                    requestJson, toJson(responseBody), "SUCCESS", null, null, duration);

            log.info("[{}] {} SUCCESS | {}ms", context.getCorrelationId(), apiName, duration);
            return responseBody;

        } catch (ApiCallException ex) {
            // Re-throw ApiCallException as-is so @Retryable picks it up
            throw ex;
        } catch (Exception ex) {
            long duration = System.currentTimeMillis() - startTime;
            trackingService.logApiCall(context, stageName, apiName,
                    requestJson, null, "FAILED", "API_CALL_ERROR", ex.getMessage(), duration);
            log.error("[{}] {} FAILED | {}ms | {}",
                    context.getCorrelationId(), apiName, duration, ex.getMessage());
            throw new ApiCallException(apiName, ex.getMessage(), ex);
        }
    }

    /**
     * Called by Spring Retry after all 3 attempts fail.
     * Method signature must match execute() with ApiCallException as first extra parameter.
     */
    @Recover
    public Map<String, Object> recoverFromApiFailure(ApiCallException ex,
                                                      ApiStep step,
                                                      String stageName,
                                                      JourneyContext context) {
        log.error("[{}] All retries exhausted for {} | stage={} | error={}",
                context.getCorrelationId(), step.getApiName(), stageName, ex.getMessage());
        throw new JourneyStageException(stageName,
                "API [" + step.getApiName() + "] failed after all retries: " + ex.getMessage());
    }

    private String getEndpointUrl(String apiName) {
        String url = apiEndpoints.get(apiName);
        if (url == null) {
            throw new IllegalStateException(
                    "No URL configured for API: " + apiName +
                    ". Add it to application.yml under api.endpoints");
        }
        return url;
    }

    private String toJson(Object obj) {
        if (obj == null) return null;
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            return "[serialization-error: " + e.getMessage() + "]";
        }
    }
}
