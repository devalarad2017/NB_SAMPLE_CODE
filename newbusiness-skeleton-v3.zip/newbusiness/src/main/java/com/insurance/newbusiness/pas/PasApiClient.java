package com.insurance.newbusiness.pas;

import com.insurance.newbusiness.journey.JourneyContext;
import com.insurance.newbusiness.tracking.JourneyTrackingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * PasApiClient — dedicated class for PAS system submission.
 *
 * WHY SEPARATE FROM ApiExecutor:
 *   PAS is the only API where we must reliably extract a specific value
 *   (applicationNumber) from the response and store it on JourneyExecution.
 *   This post-processing is important enough to justify its own class.
 *   All other APIs use the generic ApiExecutor.
 *
 * PAS REQUEST:
 *   buildPasRequest() assembles the final payload from all accumulated
 *   data in JourneyContext. TODO: fill in the actual PAS field mapping here
 *   once the PAS API contract is available.
 */
@Service
public class PasApiClient {

    private static final Logger log      = LoggerFactory.getLogger(PasApiClient.class);
    private static final String STAGE    = "PAS_SUBMISSION_STAGE";
    private static final String API_NAME = "PAS_API";

    @Value("${api.endpoints.PAS_API}")
    private String pasUrl;

    @Autowired private RestTemplate restTemplate;
    @Autowired private JourneyTrackingService trackingService;

    @Retryable(
            value = {RuntimeException.class},
            maxAttempts = 3,
            backoff = @Backoff(delay = 3000, multiplier = 2)
    )
    public String submitAndGetApplicationNumber(JourneyContext context) {
        long start = System.currentTimeMillis();
        log.info("[{}] Submitting to PAS system", context.getCorrelationId());

        try {
            Map<String, Object> pasRequest = buildPasRequest(context);
            Map response = restTemplate.postForObject(pasUrl, pasRequest, Map.class);

            long duration = System.currentTimeMillis() - start;

            // TODO: replace "applicationNumber" with actual PAS response field name
            String applicationNumber = (String) response.get("applicationNumber");

            if (applicationNumber == null || applicationNumber.trim().isEmpty()) {
                throw new RuntimeException("PAS returned empty applicationNumber");
            }

            trackingService.logApiCall(context, STAGE, API_NAME,
                    null, applicationNumber, "SUCCESS", null, null, duration);

            log.info("[{}] PAS success | applicationNumber={} | {}ms",
                    context.getCorrelationId(), applicationNumber, duration);

            return applicationNumber;

        } catch (Exception ex) {
            long duration = System.currentTimeMillis() - start;
            trackingService.logApiCall(context, STAGE, API_NAME,
                    null, null, "FAILED", "PAS_ERROR", ex.getMessage(), duration);
            log.error("[{}] PAS failed: {}", context.getCorrelationId(), ex.getMessage());
            throw ex;
        }
    }

    /**
     * Assembles the PAS request from accumulated journey data.
     * Sources:
     *   context.getRawParams()      — original partner stringvalN fields
     *   context.getEnrichedParams() — computed values (scores, premium, decisions)
     *   context.getStageResults()   — full API responses if needed
     *
     * TODO: replace placeholder logic with actual PAS API contract fields.
     */
    private Map<String, Object> buildPasRequest(JourneyContext context) {
        Map<String, Object> request = new LinkedHashMap<>();

        // Raw params from partner
        request.put("applicantName", context.getRawParams().get("stringval1"));
        request.put("dateOfBirth",   context.getRawParams().get("stringval3"));

        // Enriched params from prior API steps
        request.put("medicalScore",          context.getEnrichedParams().get("medicalScore"));
        request.put("riskCategory",          context.getEnrichedParams().get("riskCategory"));
        request.put("calculatedPremium",     context.getEnrichedParams().get("calculatedPremium"));
        request.put("underwritingDecision",  context.getEnrichedParams().get("underwritingDecision"));

        // TODO: add all remaining fields required by PAS API contract
        return request;
    }
}
