package com.insurance.newbusiness.mapping;

import com.insurance.newbusiness.domain.entity.PartnerFieldMapping;
import com.insurance.newbusiness.exception.MappingValidationException;
import com.insurance.newbusiness.repository.PartnerFieldMappingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

// ─────────────────────────────────────────────────────────────────────────────
// MappingCache
//
// Loads ALL active rows from partner_field_mapping at startup into memory.
// Key = "partnerCode::targetApi"   Value = list of mapping rows for that pair.
// No DB hit per request — pure in-memory lookup.
// Refreshed by restarting the application.
// ─────────────────────────────────────────────────────────────────────────────
@Component
class MappingCache {

    private static final Logger log = LoggerFactory.getLogger(MappingCache.class);

    @Autowired
    private PartnerFieldMappingRepository repository;

    private final Map<String, List<PartnerFieldMapping>> cache = new HashMap<>();

    @PostConstruct
    public void load() {
        List<PartnerFieldMapping> all = repository.findByActiveTrue();
        cache.clear();
        for (PartnerFieldMapping m : all) {
            String key = buildKey(m.getPartnerCode(), m.getTargetApi());
            cache.computeIfAbsent(key, k -> new ArrayList<>()).add(m);
        }
        log.info("Mapping cache loaded — {} partner+api combinations, {} total rows",
                cache.size(), all.size());
    }

    public List<PartnerFieldMapping> getMappings(String partnerCode, String targetApi) {
        return cache.getOrDefault(buildKey(partnerCode, targetApi), Collections.emptyList());
    }

    private String buildKey(String partnerCode, String targetApi) {
        return partnerCode + "::" + targetApi;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ParameterMappingService
//
// Converts the partner's 600 generic stringvalN params into a typed
// Map<String, Object> for a specific downstream API.
//
// RESOLUTION PRIORITY for each field (highest to lowest):
//   1. enrichedParams   — computed output from a prior API's PostProcessor
//   2. rawParams value  — actual stringvalN value sent by the partner
//   3. default_value    — fallback configured in partner_field_mapping table
//   4. mandatory check  — if still null after default → collect and throw once
//
// DEFAULT VALUE BEHAVIOUR:
//   If partner sends blank/null for a param AND default_value is set in the
//   mapping table, the default is used as the raw value.
//   The default is then type-converted and transformation-applied exactly
//   the same as a real partner value.
//   If default_value is also blank and is_mandatory=true → MappingValidationException.
//   If default_value is blank and is_mandatory=false → field is omitted from request.
// ─────────────────────────────────────────────────────────────────────────────
@Service
public class ParameterMappingService {

    private static final Logger log = LoggerFactory.getLogger(ParameterMappingService.class);

    @Autowired
    private MappingCache mappingCache;

    /**
     * @param partnerCode    e.g. "PARTNER_A"
     * @param targetApi      e.g. "MEDICAL_API" — must match ApiName enum value exactly
     * @param rawParams      the 600 stringval1..N from the partner inbound request
     * @param enrichedParams computed values added by PostProcessors of prior API steps
     * @return typed Map ready to be serialised as JSON request body
     */
    public Map<String, Object> resolve(String partnerCode,
                                       String targetApi,
                                       Map<String, String> rawParams,
                                       Map<String, Object> enrichedParams) {

        List<PartnerFieldMapping> mappings = mappingCache.getMappings(partnerCode, targetApi);

        if (mappings.isEmpty()) {
            log.warn("No mapping rows found — partnerCode={} targetApi={}", partnerCode, targetApi);
        }

        Map<String, Object> resolved      = new LinkedHashMap<>();
        List<String>        missingFields  = new ArrayList<>();

        for (PartnerFieldMapping mapping : mappings) {

            // Priority 1: enrichedParam — computed from a prior API step's PostProcessor
            if (enrichedParams.containsKey(mapping.getTargetField())) {
                resolved.put(mapping.getTargetField(),
                             enrichedParams.get(mapping.getTargetField()));
                continue;
            }

            // Priority 2: raw value from partner
            String rawValue  = rawParams.get(mapping.getSourceParam());
            boolean isBlank  = (rawValue == null || rawValue.trim().isEmpty());

            // Priority 3: fall back to default_value if raw is blank
            if (isBlank && mapping.getDefaultValue() != null
                        && !mapping.getDefaultValue().trim().isEmpty()) {
                rawValue = mapping.getDefaultValue();
                isBlank  = false;
                log.debug("Using default value for field={} api={}", mapping.getTargetField(), targetApi);
            }

            // Priority 4: mandatory check
            if (isBlank) {
                if (mapping.isMandatory()) {
                    // Collect ALL missing fields before throwing — easier to debug
                    missingFields.add(mapping.getSourceParam() + " -> " + mapping.getTargetField());
                }
                // Not mandatory and no default — omit the field from request
                continue;
            }

            // Apply transformation then type conversion
            String transformed = applyTransformation(rawValue, mapping.getTransformation());
            Object typed       = convertToType(transformed, mapping.getDataType(), mapping.getDateFormat());
            resolved.put(mapping.getTargetField(), typed);
        }

        // Throw once with ALL missing fields listed — avoids fix-one-at-a-time loops
        if (!missingFields.isEmpty()) {
            throw new MappingValidationException(targetApi, missingFields);
        }

        return resolved;
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private String applyTransformation(String value, String transformation) {
        if (transformation == null || transformation.trim().isEmpty()) {
            return value;
        }
        switch (transformation.toUpperCase()) {
            case "TRIM":      return value.trim();
            case "UPPERCASE": return value.trim().toUpperCase();
            case "LOWERCASE": return value.trim().toLowerCase();
            default:          return value;
        }
    }

    private Object convertToType(String value, String dataType, String dateFormat) {
        if (value == null) {
            return null;
        }
        switch (dataType.toUpperCase()) {
            case "STRING":  return value;
            case "INTEGER": return Integer.parseInt(value.trim());
            case "DECIMAL": return new BigDecimal(value.trim());
            case "BOOLEAN": return Boolean.parseBoolean(value.trim());
            case "DATE":
                DateTimeFormatter fmt = DateTimeFormatter.ofPattern(dateFormat);
                return LocalDate.parse(value.trim(), fmt);
            default:
                log.warn("Unknown dataType '{}' — treating as STRING", dataType);
                return value;
        }
    }
}
