package com.insurance.newbusiness.service;

import com.insurance.newbusiness.domain.dto.InboundRequest;
import com.insurance.newbusiness.domain.entity.RawRequest;
import com.insurance.newbusiness.journey.JourneyContext;
import com.insurance.newbusiness.journey.JourneyOrchestrator;
import com.insurance.newbusiness.pas.PasApiClient;
import com.insurance.newbusiness.repository.RawRequestRepository;
import com.insurance.newbusiness.reversefeed.PartnerNotifierFactory;
import com.insurance.newbusiness.tracking.JourneyTrackingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

/**
 * NewBusinessService — top-level coordinator.
 *
 * SYNC PART (receiveAndAcknowledge):
 *   Runs on the HTTP request thread. Must be fast.
 *   1. Generate correlationId — added to MDC for all downstream log lines
 *   2. Store raw request to DB — immutable record before any processing
 *   3. Create journey_execution record
 *   4. Trigger async journey — returns correlationId to controller immediately
 *   Controller returns 202 Accepted to partner.
 *
 * ASYNC PART (processJourney):
 *   Runs on journeyTaskExecutor thread pool. Partner already received 202.
 *   1. Run all journey stages (eligibility → scoring → medical → KYC → premium
 *      → underwriting → document → proposal)
 *   2. Submit to PAS — get applicationNumber
 *   3. Store applicationNumber on journey_execution
 *   4. Send reverse feed to partner
 *
 * ASYNC EXCEPTIONS:
 *   Exceptions in processJourney() do NOT reach GlobalExceptionHandler.
 *   They are caught here, logged, and journey_execution.overall_status = FAILED.
 *   A retry can be triggered later (manually or via scheduled job) using correlationId.
 *   JourneyOrchestrator will skip already-succeeded APIs on retry.
 */
@Service
public class NewBusinessService {

    private static final Logger log = LoggerFactory.getLogger(NewBusinessService.class);

    @Autowired private RawRequestRepository    rawRequestRepository;
    @Autowired private JourneyTrackingService  trackingService;
    @Autowired private JourneyOrchestrator     journeyOrchestrator;
    @Autowired private PasApiClient            pasApiClient;
    @Autowired private PartnerNotifierFactory  notifierFactory;

    /**
     * Synchronous part — fast. Returns correlationId. Partner ACK'd here.
     */
    @Transactional
    public String receiveAndAcknowledge(InboundRequest inboundRequest) {
        String correlationId = UUID.randomUUID().toString();
        MDC.put("correlationId", correlationId);

        RawRequest rawRequest = new RawRequest();
        rawRequest.setCorrelationId(correlationId);
        rawRequest.setPartnerCode(inboundRequest.getPartnerCode());
        rawRequest.setRawPayload(toJson(inboundRequest.getParams()));
        rawRequestRepository.save(rawRequest);

        JourneyContext context = new JourneyContext(
                correlationId,
                inboundRequest.getPartnerCode(),
                inboundRequest.getParams()
        );

        trackingService.initJourney(context, rawRequest.getId());

        log.info("[{}] Request received and stored | partner={}",
                correlationId, inboundRequest.getPartnerCode());

        // Fire async — processJourney runs on journeyTaskExecutor, HTTP response returns now
        processJourney(context);

        return correlationId;
    }

    /**
     * Async journey — runs on journeyTaskExecutor thread. Partner already got 202.
     */
    @Async("journeyTaskExecutor")
    public void processJourney(JourneyContext context) {
        try {
            MDC.put("correlationId", context.getCorrelationId());

            // Run all configured stages in order
            journeyOrchestrator.execute(context);

            // PAS submission — separate because it returns applicationNumber
            String applicationNumber = pasApiClient.submitAndGetApplicationNumber(context);
            context.setApplicationNumber(applicationNumber);
            trackingService.markJourneyCompleted(context);

            // Reverse feed — push application details to partner callback URL
            notifierFactory
                    .getNotifier(context.getPartnerCode())
                    .notify(context, applicationNumber);

            log.info("[{}] Journey fully completed | applicationNumber={}",
                    context.getCorrelationId(), applicationNumber);

        } catch (Exception ex) {
            log.error("[{}] Journey failed: {}", context.getCorrelationId(), ex.getMessage(), ex);
            // journey_execution.overall_status left as FAILED
            // Use correlationId to retry — JourneyOrchestrator resumes from failed API
        } finally {
            MDC.clear();
        }
    }

    private String toJson(Object obj) {
        try {
            return new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            return "[serialization-error]";
        }
    }
}
