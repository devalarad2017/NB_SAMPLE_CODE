package com.insurance.newbusiness;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableRetry      // Activates @Retryable on ApiExecutor
@EnableAsync      // Activates @Async on NewBusinessService
public class NewBusinessApplication {

    public static void main(String[] args) {
        SpringApplication.run(NewBusinessApplication.class, args);
    }
}
