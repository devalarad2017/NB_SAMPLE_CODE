package com.insurance.newbusiness.journey;

import java.util.*;

/**
 * JourneyContext is created once per inbound request and passed through
 * every stage and every API step. Single shared state — no static, no ThreadLocal.
 *
 * correlationId   immutable, UUID, in every log line via MDC
 * partnerCode     immutable, used for mapping lookup and reverse feed
 * rawParams       immutable, the 600 stringval1..N from partner
 * enrichedParams  mutable, populated by PostProcessors, priority input to later APIs
 * stageResults    mutable, full response per apiName — available to PostProcessors
 * applicationNumber  set after PAS success, passed to reverse feed
 *
 * enrichedParams and stageResults use synchronizedMap because parallel API steps
 * (EDC, PASA, TASA) may write concurrently during SCORING_STAGE.
 */
public class JourneyContext {

    private final String correlationId;
    private final String partnerCode;
    private final Map<String, String> rawParams;
    private final Map<String, Object> enrichedParams;
    private final Map<String, Object> stageResults;
    private String applicationNumber;

    public JourneyContext(String correlationId, String partnerCode, Map<String, String> rawParams) {
        this.correlationId  = correlationId;
        this.partnerCode    = partnerCode;
        this.rawParams      = Collections.unmodifiableMap(new HashMap<>(rawParams));
        this.enrichedParams = Collections.synchronizedMap(new LinkedHashMap<>());
        this.stageResults   = Collections.synchronizedMap(new LinkedHashMap<>());
    }

    /** Called by PostProcessor to store computed value for later API steps. */
    public void addEnrichedParam(String key, Object value) { enrichedParams.put(key, value); }

    /** Called by JourneyOrchestrator to store full API response. */
    public void addStageResult(String apiName, Object result) { stageResults.put(apiName, result); }

    public String getCorrelationId()               { return correlationId; }
    public String getPartnerCode()                 { return partnerCode; }
    public Map<String, String> getRawParams()      { return rawParams; }
    public Map<String, Object> getEnrichedParams() { return enrichedParams; }
    public Map<String, Object> getStageResults()   { return stageResults; }
    public String getApplicationNumber()           { return applicationNumber; }
    public void setApplicationNumber(String n)     { this.applicationNumber = n; }
}
