package com.insurance.newbusiness.journey;

import com.insurance.newbusiness.integration.ApiExecutor;
import com.insurance.newbusiness.tracking.JourneyTrackingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * JourneyOrchestrator drives the full request processing journey.
 *
 * STAGE ORDER: Always preserved — both on first run and on retry.
 *
 * API-LEVEL RETRY RESUME:
 *   On retry, loads api_names with status=SUCCESS from journey_stage_log.
 *   Any ApiStep in that set is SKIPPED. Journey resumes at the exact failed API.
 *
 *   Example — SCORING_STAGE: EDC+PASA succeeded, TASA failed.
 *   Retry: EDC skipped, PASA skipped, TASA runs.
 *
 * ADDING A NEW API (no new class needed):
 *   1. Add to ApiName enum
 *   2. Add URL to application.yml under api.endpoints
 *   3. Add rows to partner_field_mapping (or BA Excel sheet)
 *   4. Add ApiStep line in initStages() below
 */
@Service
public class JourneyOrchestrator {

    private static final Logger log = LoggerFactory.getLogger(JourneyOrchestrator.class);

    @Autowired private ApiExecutor apiExecutor;
    @Autowired private JourneyTrackingService trackingService;
    @Autowired @Qualifier("journeyTaskExecutor") private Executor taskExecutor;

    private List<StageDefinition> stages;

    // ─────────────────────────────────────────────────────────────────────────
    // FULL JOURNEY DEFINITION — one place to see and change everything.
    // Stage order here = execution order always.
    // ─────────────────────────────────────────────────────────────────────────
    @PostConstruct
    public void initStages() {
        stages = new ArrayList<>();

        // Stage 1: Eligibility — must pass before any other stage runs
        stages.add(new StageDefinition("ELIGIBILITY_STAGE", Arrays.asList(
                ApiStep.of("ELIGIBILITY_API")
        )));

        // Stage 2: Scoring — EDC, PASA, TASA run in parallel for speed
        stages.add(new StageDefinition("SCORING_STAGE", Arrays.asList(
                ApiStep.parallel("EDC_API"),
                ApiStep.parallel("PASA_API"),
                ApiStep.parallel("TASA_API")
        )));

        // Stage 3: Medical assessment
        // PostProcessor pushes score + riskCategory into enrichedParams
        // so UNDERWRITING_API can use them without a raw stringvalN param
        stages.add(new StageDefinition("MEDICAL_STAGE", Arrays.asList(
                ApiStep.of("MEDICAL_API")
                       .withPostProcessor((context, response) -> {
                           // TODO: replace keys with actual MEDICAL_API response field names
                           context.addEnrichedParam("medicalScore",  response.get("score"));
                           context.addEnrichedParam("riskCategory",  response.get("riskCategory"));
                           context.addEnrichedParam("medicalStatus", response.get("status"));
                       })
        )));

        // Stage 4: KYC verification
        stages.add(new StageDefinition("KYC_STAGE", Arrays.asList(
                ApiStep.of("KYC_API")
        )));

        // Stage 5: Premium calculation
        // PostProcessor pushes calculated premium into enrichedParams
        stages.add(new StageDefinition("PREMIUM_STAGE", Arrays.asList(
                ApiStep.of("PREMIUM_CALC_API")
                       .withPostProcessor((context, response) -> {
                           // TODO: replace keys with actual PREMIUM_CALC_API response field names
                           context.addEnrichedParam("calculatedPremium", response.get("premiumAmount"));
                           context.addEnrichedParam("premiumFrequency",  response.get("frequency"));
                       })
        )));

        // Stage 6: Underwriting — automatically uses medicalScore from enrichedParams
        // (added by MEDICAL_API PostProcessor above — no extra code needed)
        stages.add(new StageDefinition("UNDERWRITING_STAGE", Arrays.asList(
                ApiStep.of("UNDERWRITING_API")
                       .withPostProcessor((context, response) -> {
                           // TODO: replace key with actual UNDERWRITING_API response field name
                           context.addEnrichedParam("underwritingDecision", response.get("decision"));
                       })
        )));

        // Stage 7: Document generation
        stages.add(new StageDefinition("DOCUMENT_STAGE", Arrays.asList(
                ApiStep.of("DOCUMENT_API")
        )));

        // Stage 8: Proposal submission — uses calculatedPremium + underwritingDecision
        stages.add(new StageDefinition("PROPOSAL_STAGE", Arrays.asList(
                ApiStep.of("PROPOSAL_SUBMIT_API")
        )));

        // NOTE: PAS and reverse feed are NOT stages here.
        // Handled in NewBusinessService after orchestration — PAS returns
        // applicationNumber which must be stored before reverse feed runs.
    }

    // ─────────────────────────────────────────────────────────────────────────
    // EXECUTION
    // ─────────────────────────────────────────────────────────────────────────

    public void execute(JourneyContext context) {
        Set<String> succeededApis = trackingService.getSucceededApiNames(context.getCorrelationId());
        boolean isRetry = !succeededApis.isEmpty();

        log.info("[{}] Journey execute | isRetry={} | alreadySucceeded={}",
                context.getCorrelationId(), isRetry, succeededApis);

        for (StageDefinition stage : stages) {
            if (!hasPendingSteps(stage, succeededApis)) {
                log.info("[{}] All APIs in stage already succeeded — skipping: {}",
                        context.getCorrelationId(), stage.getStageName());
                continue;
            }
            executeStage(stage, context, succeededApis);
        }
    }

    private void executeStage(StageDefinition stage, JourneyContext context,
                               Set<String> succeededApis) {
        log.info("[{}] Stage starting: {}", context.getCorrelationId(), stage.getStageName());
        trackingService.markStageStarted(context, stage.getStageName());

        List<ApiStep> parallelPending    = new ArrayList<>();
        List<ApiStep> sequentialPending  = new ArrayList<>();

        for (ApiStep step : stage.getSteps()) {
            if (succeededApis.contains(step.getApiName())) {
                log.info("[{}] Skipping already succeeded API: {}",
                        context.getCorrelationId(), step.getApiName());
                continue;
            }
            if (step.isParallel()) {
                parallelPending.add(step);
            } else {
                sequentialPending.add(step);
            }
        }

        // All parallel steps first — must all complete before sequential steps begin
        if (!parallelPending.isEmpty()) {
            runParallel(parallelPending, context, stage.getStageName());
        }

        // Sequential steps run in the exact order defined in initStages()
        for (ApiStep step : sequentialPending) {
            runStep(step, context, stage.getStageName());
        }

        trackingService.markStageCompleted(context, stage.getStageName());
        log.info("[{}] Stage completed: {}", context.getCorrelationId(), stage.getStageName());
    }

    private void runParallel(List<ApiStep> steps, JourneyContext context, String stageName) {
        List<CompletableFuture<Void>> futures = new ArrayList<>();
        for (ApiStep step : steps) {
            CompletableFuture<Void> future = CompletableFuture.runAsync(
                    () -> runStep(step, context, stageName), taskExecutor);
            futures.add(future);
        }
        // Block until all complete — any exception propagates and stops the stage
        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
    }

    private void runStep(ApiStep step, JourneyContext context, String stageName) {
        Map<String, Object> response = apiExecutor.execute(step, stageName, context);
        context.addStageResult(step.getApiName(), response);
        if (step.hasPostProcessor()) {
            step.getPostProcessor().process(context, response);
        }
    }

    private boolean hasPendingSteps(StageDefinition stage, Set<String> succeededApis) {
        for (ApiStep step : stage.getSteps()) {
            if (!succeededApis.contains(step.getApiName())) {
                return true;
            }
        }
        return false;
    }
}
