package com.insurance.newbusiness.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.client.RestTemplate;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * AppConfig — all shared infrastructure beans in one place.
 *
 * Swagger UI: http://localhost:8080/swagger-ui.html
 * OpenAPI JSON: http://localhost:8080/v3/api-docs
 */
@Configuration
public class AppConfig {

    // ── Thread Pool ───────────────────────────────────────────────────────────
    // Used by JourneyOrchestrator for:
    //   1. Running parallel API steps (EDC, PASA, TASA) concurrently
    //   2. Running the full journey async so the 202 response is immediate
    //
    // Sizing: 3 parallel scoring APIs per request × ~15 concurrent requests = 45 threads max
    @Bean(name = "journeyTaskExecutor")
    public Executor journeyTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(10);
        executor.setMaxPoolSize(50);
        executor.setQueueCapacity(100);
        executor.setThreadNamePrefix("journey-");
        // CallerRunsPolicy: if queue is full, calling thread runs the task — no request dropped
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        executor.initialize();
        return executor;
    }

    // ── RestTemplate ─────────────────────────────────────────────────────────
    // Shared across all ApiExecutor calls.
    // TODO: tune connectTimeout and readTimeout based on downstream API SLAs.
    @Bean
    public RestTemplate restTemplate() {
        HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
        factory.setConnectTimeout(5000);   // 5 seconds to establish connection
        factory.setReadTimeout(30000);     // 30 seconds to wait for response
        return new RestTemplate(factory);
    }

    // ── ObjectMapper ─────────────────────────────────────────────────────────
    // JavaTimeModule handles LocalDate / LocalDateTime serialization.
    @Bean
    public ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        return mapper;
    }

    // ── Swagger / OpenAPI ────────────────────────────────────────────────────
    // Access Swagger UI at: http://localhost:8080/swagger-ui.html
    @Bean
    public OpenAPI openAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Insurance New Business Platform API")
                        .description(
                            "Receives insurance applications from external partners. " +
                            "Orchestrates eligibility, scoring, medical, KYC, premium, " +
                            "underwriting, and PAS submission stages. " +
                            "Returns application number via reverse feed callback.")
                        .version("1.0.0")
                        .contact(new Contact()
                                .name("Insurance Platform Team"))
                        .license(new License()
                                .name("Internal Use Only")));
    }
}
