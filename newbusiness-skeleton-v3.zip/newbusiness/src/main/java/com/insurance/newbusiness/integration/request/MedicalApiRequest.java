package com.insurance.newbusiness.integration.request;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Sample POJO for MEDICAL_API — shows the pattern for nested JSON requests.
 *
 * USE THIS PATTERN when a downstream API expects nested JSON like:
 * {
 *   "applicant": { "firstName": "John", "dateOfBirth": "1985-03-12" },
 *   "policy":    { "sumAssured": 5000000, "term": 20 }
 * }
 *
 * For flat JSON APIs you do NOT need a POJO — ApiExecutor posts the Map directly.
 *
 * HOW TO WIRE IT in JourneyOrchestrator:
 *
 *   ApiStep.of("MEDICAL_API")
 *          .withRequestBuilder(params -> {
 *              MedicalApiRequest req = new MedicalApiRequest();
 *              req.getApplicant().setFirstName((String) params.get("firstName"));
 *              req.getApplicant().setDateOfBirth((LocalDate) params.get("dateOfBirth"));
 *              req.getPolicy().setSumAssured((BigDecimal) params.get("sumAssured"));
 *              req.getPolicy().setTerm((Integer) params.get("term"));
 *              return req;
 *          })
 *          .withPostProcessor((context, response) -> {
 *              context.addEnrichedParam("medicalScore", response.get("score"));
 *          })
 *
 * params Map keys must match the target_field values in partner_field_mapping table.
 * RestTemplate serialises this POJO to nested JSON automatically via Jackson.
 */
public class MedicalApiRequest {

    private Applicant applicant = new Applicant();
    private Policy    policy    = new Policy();

    public Applicant getApplicant() { return applicant; }
    public void setApplicant(Applicant applicant) { this.applicant = applicant; }
    public Policy getPolicy() { return policy; }
    public void setPolicy(Policy policy) { this.policy = policy; }

    // ── Inner classes — each maps to a nested JSON object ────────────────────

    public static class Applicant {
        private String    firstName;
        private String    lastName;
        private LocalDate dateOfBirth;
        private String    panNumber;

        public String getFirstName() { return firstName; }
        public void setFirstName(String firstName) { this.firstName = firstName; }
        public String getLastName() { return lastName; }
        public void setLastName(String lastName) { this.lastName = lastName; }
        public LocalDate getDateOfBirth() { return dateOfBirth; }
        public void setDateOfBirth(LocalDate dateOfBirth) { this.dateOfBirth = dateOfBirth; }
        public String getPanNumber() { return panNumber; }
        public void setPanNumber(String panNumber) { this.panNumber = panNumber; }
    }

    public static class Policy {
        private BigDecimal sumAssured;
        private Integer    term;

        public BigDecimal getSumAssured() { return sumAssured; }
        public void setSumAssured(BigDecimal sumAssured) { this.sumAssured = sumAssured; }
        public Integer getTerm() { return term; }
        public void setTerm(Integer term) { this.term = term; }
    }
}
